import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from core import (
 handlers,
 create_tables,
 middlewares
)

create_tables.create_all()
PROXY_URL = "http://proxy.server:3128"
#dp = Dispatcher(Bot(token="6126740167:AAEBLoKiRFEkOG9qecmMs8Rxgo6WEB3B9V4"), storage=MemoryStorage()) #TEST
dp = Dispatcher(Bot(token="6646286137:AAFmzuqOAV5ix6EH6e86EUUTBDuKRqWdzUg"), storage=MemoryStorage()) #ORIG

async def main():
    print("Server started!")
    handlers.register_handlers(dp)
    dp.setup_middleware(middlewares.AntiAnonimousMiddleware())
    dp.setup_middleware(middlewares.AutoRegistrationMiddleware())
    await dp.bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(allowed_updates=types.AllowedUpdates.all())

asyncio.run(main())