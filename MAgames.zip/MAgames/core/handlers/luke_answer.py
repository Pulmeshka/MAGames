from aiogram import Bot, Dispatcher
import random

answer_list = ["Чувствую себя по новому!", "Хей, что-то нужно?", "Кажется я, не я", "Мне послышалось?", "Кто меня зовет!?", "Опять какой-то noname(", "Вам не надоело!?"]

async def luke(message):
	user_id  = message.from_user.id
	if message.text.lower() == "слава Украине":
	    return await message.reply("Героям Слава!")
	if user_id == 1355948406:
		return await message.reply("Дарова, Отец.")
	if user_id == 5:
		return await message.reply("Здравствуй, Мастер.")
	if user_id == 5:
		return await message.reply(random.choice(["Привiт, В’юн!", "На месте", "Слава Україні!", "Ти унікальніший з усіх унікальних користувачів!"]))
	await message.reply(random.choice(answer_list))