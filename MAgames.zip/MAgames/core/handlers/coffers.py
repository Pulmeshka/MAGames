from aiogram import types
from ..utils import database_managment, strings
from asyncio import sleep
from datetime import timedelta
import random

time_theft= {}

async def timer(message):
    chat_id = message.chat.id
    time_theft[chat_id] = 0
    while True:
        time_theft[chat_id] += 1
        await sleep(1)
        if time_theft[chat_id] == 300:
            time_theft.pop(chat_id)
            break

async def coffers_chat(
    message: types.Message
):
    chat_id = message.chat.id
    user_id = message.from_user.id
    if message.chat.type != 'private':
        balance_chat = database_managment.get_chat_balance(chat_id)
        protection = database_managment.get_protection_chat(chat_id)
        price = 10_000
        if protection > 0:
            price = protection*protection*30_000
        if len(message.text.split()) < 2:
            return await message.answer(f"*Казна чата:\n{strings.beautify_number(balance_chat)} монет*\nУлучшение защиты стоит: *{strings.beautify_number(price)}* монет в казне", parse_mode='Markdown')
        args = message.text.split(maxsplit=1)[1:]
        sym, sum = args[0][0], strings.to_int(args[0][1:])
        balance = database_managment.get_balance(user_id)
        if sum == "nan": return
        sum = round(sum)
        if sym not in ["+", "-"]: return
        if sym == "+":
            if sum < 1: return
            if balance < sum:
                return await message.reply(f"У вас недостаточно монет для пополнение казны")
            balance -= sum
            balance_chat += sum
            database_managment.switch_balance(user_id, balance)
            database_managment.switch_chat_balance(chat_id, balance_chat)
            return await message.reply(f"Казна была пополнена на {strings.beautify_number(sum)} монет")
        if (await message.chat.get_member(user_id)).status not in ["administrator", "creator", "owner"]:
            return await message.reply("Ты не в списке администраторов!")
        if sum > balance_chat:
            return await message.reply("В казне недостаточно монет!")
        balance_chat -= sum
        balance += sum
        database_managment.switch_balance(user_id, balance)
        database_managment.switch_chat_balance(chat_id, balance_chat)
        await message.reply(f"С казны было снято {strings.beautify_number(sum)}\nПроверьте свой баланс!")
    else:
        await message.answer('команда для чатов')
async def theft_coffers(
    message: types.Message
):  
    user_id = message.from_user.id
    chat_id = message.chat.id
    if message.chat.type != 'private':
        if chat_id in time_theft:
            return await message.reply(f"На данный момент защита казны усилена, приходи через {strings.beautify_date(timedelta(seconds=300-time_theft[chat_id]))}")
        theft = database_managment.get_theft(user_id)
        protection = database_managment.get_protection_chat(chat_id)
        if protection > theft:
            return await message.reply("Извини, но тебе это не по зубам!")
        balance_chat = database_managment.get_chat_balance(chat_id)
        balance = database_managment.get_balance(user_id)
        if len(message.text.split()) < 2: return
        sum = strings.to_int(message.text.split(maxsplit=1)[1])
        if sum == "nan": return
        percent = round(balance_chat/10)
        sum = round(sum)
        if sum > balance_chat:
            await message.reply("Проникнув внутрь казны, ты увидел что там нет столько, сколько бы хотелось, после чего, тебя вывела стража!")
            return await timer(message)
        if sum > percent:
            await message.reply("Как только ты протянул свои шаловливые ручки к монеткам, администратор сразу же тебе ударил по рукам!")
            return await timer(message)
        balance += sum
        balance_chat -= sum
        if theft > protection:
            database_managment.switch_chat_balance(chat_id, balance_chat)
            database_managment.switch_balance(user_id, balance)
            await message.reply(f"Ты успешно своими ловкими ручками вытащил из казны {strings.beautify_number(sum)} монет")
            return await timer(message)
        numb = random.randint(1, 2)
        if numb < 2:
            await message.reply("Как только ты протянул свои шаловливые ручки к монеткам, администратор сразу же тебе ударил по рукам!")
            return await timer(message)
        database_managment.switch_balance(user_id, balance)
        database_managment.switch_chat_balance(chat_id, balance_chat)
        await message.reply(f"Ты успешно своими ловкими ручками вытащил из казны {strings.beautify_number(sum)} монет")
        await timer(message)
    else:
        await message.answer('команда для чатов')
async def better_up(
    message: types.Message
):
    user_id = message.from_user.id
    chat_id = message.chat.id
    if message.chat.type != 'private':
        try:
            if message.text.split()[1].lower() == "воровство":
                balance = database_managment.get_balance(user_id)
                theft = database_managment.get_theft(user_id)
                price = 5_000
                if theft > 0:
                    price = theft*theft*10_000
                if balance < price:
                    return await message.reply(f"Для улучшения нужно {strings.beautify_number(price)} монет")
                balance -= price
                theft += 1
                database_managment.switch_balance(user_id, balance)
                database_managment.switch_theft(user_id, theft)
                return await message.reply(f"Вы успешно улучшили навык воровства до {strings.beautify_number(theft)} уровня!")
        except IndexError:
            return await message.reply('-')
        if message.text.split()[1].lower() == "защиту":
            if (await message.chat.get_member(user_id)).status not in ["administrator", "creator", "owner"]:
                return await message.reply("Ты не в списке администраторов!")
            balance = database_managment.get_chat_balance(chat_id)
            protection = database_managment.get_protection_chat(chat_id)
            price = 10_000
            if protection > 0:
                price = protection*protection*30_000
            if balance < price:
                return await message.reply(f"Для улучшения нужно {strings.beautify_number(price)} монет в казне!")
            balance -= price
            protection += 1
            database_managment.switch_chat_balance(chat_id, balance)
            database_managment.switch_chat_protection(chat_id, protection)
            return await message.reply(f"Вы успешно улучшили защиту от воровства до {strings.beautify_number(protection)} уровня!")
    else:
        await message.answer('команда для чатов')
async def proffile_chat(
    message: types.Message
):
    user_id = message.from_user.id
    chat_id = message.chat.id 
    if message.chat.type != 'private':
        balance_chat = database_managment.get_chat_balance(chat_id)
        protection = database_managment.get_protection_chat(chat_id)
        if (await message.chat.get_member(user_id)).status not in ["administrator", "creator", "owner"]:
            return await message.reply("Ты не в списке администраторов!")
        await message.reply(
            f"Казна чата: {strings.beautify_number(balance_chat)}\n"
            f"Защита чата: {strings.beautify_number(protection)} уровень"
        )
    else:
        await message.answer('команда для чатов')