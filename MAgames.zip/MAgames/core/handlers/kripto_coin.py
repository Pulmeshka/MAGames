from asyncio import sleep
import random
from aiogram import types
import os
from ..utils import strings, database_managment

channel = -1002095555435
chat = -1002095555435

if not os.path.exists("kripto_price.txt"):
    with open("kripto_price.txt","w") as f:
        f.write("10000")
    kripto_price = 10000
else:
    with open("kripto_price.txt","r") as f:
        kripto_price = int(f.read())

timer = 59

cheker = True

async def kripto_start(
    message: types.Message
):
    global timer, kripto_price, cheker
    user_id = message.from_user.id
    vip = database_managment.get_vip(user_id)
    cheker = False
    await message.bot.send_message(chat, "Курс запущен✅")
    while True:
        random_number = random.randint(1000, 10000)
        number_chek = random.randint(1, 4)
        price = kripto_price/random_number
        if number_chek >= 3:
            kripto_price += price
        else:
            kripto_price -= price
        await sleep(1)
        timer += 1
        if timer == 60 or timer > 60:
    	    timer = 0
    	    with open("kripto_price.txt","w") as f:
                f.write(f"{round(kripto_price)}")
    	    await message.bot.send_message(channel, f"Новый курс💎: {strings.beautify_number(round(kripto_price))}💰")

async def kripto_trade(
    message: types.Message
):

    with open("kripto_price.txt","r") as f:
        kripto_price = int(f.read())
    user_id = message.from_user.id
    chat_id = message.chat.id
    kripto = database_managment.get_kripto(user_id)
    balance = database_managment.get_balance(user_id)
    if len(message.text.split()) < 2:
        await message.reply(f"Ваши кристаллы:\n<code>{kripto}</code>💎\nкупить - кристаллы +[сума]\nпродать - кристаллы - [сума]", parse_mode="HTML")
        if cheker:
            return await kripto_start(message)
        return
    args = message.text.split(maxsplit=1)[1:]
    sym, sums = args[0][0], strings.to_int(args[0][1:])
    if sums == "nan":
        await message.reply("Проверь правильность написания комнды!")
        if cheker:
            return await kripto_start(message)
        return
    sums = float(args[0][1:])
    if sym == "-":
        if sums > kripto:
            await message.reply("У вас недостаточно облигаций для продажи!")
            if cheker:
                return await kripto_start(message)
            return await kripto_start(message)
        if sums < 0.01:
            return await message.reply("Минимально 0.01 кристаллов возможно продать")
        balance += round(sums*kripto_price)
        database_managment.switch_balance(user_id, balance)
        kripto -= sums
        database_managment.switch_kripto(user_id, kripto)
        text = (
        f"Вы продали {sums} кристаллов на сумму {strings.beautify_number(round(sums*kripto_price))}\n\n"
        )
        await message.reply(text)
        if cheker:
            return await kripto_start(message)
        return

    if sym == "+":
        sum_for_balance = round(sums*kripto_price)
        if sum_for_balance > balance:
            await message.reply("У вас недостаточно монет для покупки")
            if cheker:
                return await kripto_start(message)
            return await message.reply("Минимально 0.01 кристаллов возможно купить")
        if sums < 0.01:
            return await kripto_start(message)
        balance -= sum_for_balance
        kripto += sums
        database_managment.switch_kripto(user_id, kripto)
        database_managment.switch_balance(user_id, balance)
        text = (
        f"Вы купили {sums} кристаллов на сумму {strings.beautify_number(round(sums*kripto_price))}\n\n"
        )
        await message.reply(text)
        if cheker:
            return await kripto_start(message)
        return

async def rate_exchange(message):
    user_id = message.chat.id
    with open("kripto_price.txt","r") as f:
        kripto_price = int(f.read())
    await message.reply(
       "Курс кристалла на данный момент:\n"
       f"{strings.beautify_number(kripto_price)} монет\n\nкурс меняеться каждую минуту\n\nСледить за курсом можно тут https://t.me/+xLy43zIUEMg1NzE6")