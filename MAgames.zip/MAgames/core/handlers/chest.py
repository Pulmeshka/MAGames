from ..utils import strings, database_managment
from aiogram import types
import random
from asyncio import sleep

async def use_chest(query: types.CallbackQuery):
    user_id = query.from_user.id

    owner_id = int(query.data.split()[1])

    if user_id != owner_id:
        return

    chest = query.data.split()[0].split("_")[1]
    if chest == "rating":
        await query.message.delete()
        return await rating_chest(query)


async def rating_chest(message: types.Message | types.CallbackQuery):
    if isinstance(message, types.CallbackQuery):
        await message.answer()
        message.answer = message.message.answer
    user_id = message.from_user.id
    rating = database_managment.get_rating(user_id)
    name = message.from_user.full_name
    if rating < 20.0:
        return await message.answer(
            f"{name}, у вас недостаточно рейтинга!\nЦена 20.0 рейтинга!"
        )

    msg = await message.answer("Вскрываю кейс /")
    await sleep(1)
    await msg.edit_text("Почти --")
    await sleep(1)
    await msg.edit_text("Вот вот уже \\")
    await sleep(1)
    rating -= 20.0
    database_managment.switch_rating(user_id, round(float(rating), 1))
    chance = ["rating", "rating", "crystal", "bond"]
    random_choice = random.choice(chance)
    if random_choice == "rating":
        count = random.randint(5, 10)
        database_managment.switch_rating(user_id, round(float(rating + count), 1))
        return await msg.edit_text(f"{name}, вам выпало {count} рейтинга!")

    if random_choice == "crystal":
        count = random.randint(1, 5)
        crystals = database_managment.get_kripto(user_id)
        database_managment.switch_kripto(user_id, crystals + count)
        return await msg.edit_text(f"{name}, вам выпало {count} кристалл(ов)")

    if random_choice == "bond":
        count = random.randint(10, 100)
        bond = database_managment.get_bank(user_id)
        database_managment.trade_bank(user_id, bond + count)

        return await msg.edit_text(f"{name}, вам выпало {count} облигаций")
