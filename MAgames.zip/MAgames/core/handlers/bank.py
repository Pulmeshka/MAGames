from aiogram import types
from ..utils import database_managment, strings

min = 31
limit = 9200000000000000000

async def bank_trade(message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    args = message.text.split(maxsplit=1)[1:]
    bank = database_managment.get_bank(user_id)
    balance = database_managment.get_balance(user_id)
    if not len(args):
        sum = round(bank*min)
        text = (
            "В банке можно обменять монеты на облигации и обратно. Цена 1 облигации:\n"
            f"{strings.beautify_number(min)}\n\nУ вас облигаций: {strings.beautify_number(bank)} на сумму {strings.beautify_number(sum)}\n"
            "Покупка: !банк +100\n"
            "Продажа: !банк -100"
)
        return await message.reply(text)
    
    sym, sum = args[0][0], strings.to_int(args[0][1:])
    if sum == "nan":
        return await message.reply("Проверь правильность написания комaнды!")
    sum = round(sum)
    if sym == "-":
        if sum > bank:
            return await message.reply("У вас недостаточно облигаций для продажи!")
        if sum < 0:
            return
        if sum*min <= limit:
            balance += round(sum*min)
            bank -= sum
            database_managment.trade_bank(user_id, bank)
            database_managment.switch_balance(user_id, balance)
        text = (
        f"Вы продали {strings.beautify_number(sum)} облигаций на сумму {strings.beautify_number(sum*min)}\n\n"
        f"У вас облигаций: {strings.beautify_number(bank)} на сумму {strings.beautify_number(bank*min)}"
        )
        return await message.reply(text)
       
    if sym == "+":
        sum_for_balance = sum*min
        if sum_for_balance > balance:
            return await message.reply("У вас недостаточно монет для покупки")
        if sum < 0:
            return
        balance -= round(sum_for_balance)
        bank += sum
        database_managment.trade_bank(user_id, bank)
        database_managment.switch_balance(user_id, balance)
        text = (
        f"Вы купили {strings.beautify_number(sum)} облигаций на сумму {strings.beautify_number(sum*min)}\n\n"
        f"У вас облигаций: {strings.beautify_number(bank)} на сумму {strings.beautify_number(bank*min)}"
        )
        return await message.reply(text)
    