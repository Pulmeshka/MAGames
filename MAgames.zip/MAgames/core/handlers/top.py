from aiogram import types
from ..utils import strings, database_managment
from .. import config
import html

admin_chat = -1001986982332

async def top_in_chat(
    message: types.Message
):
    if message.chat.type == "private": return
    chat_id = message.chat.id
    top = database_managment.top_chat(chat_id)
    text = "Топ чата:\n"
    for user_id, balance in top:
	    chatmember: types.ChatMember = await message.chat.get_member(user_id)
	    name = chatmember.user.full_name
	    text += f"{name}: {strings.beautify_number(balance)}\n"
    await message.reply(text)
    
async def top_bank_for_admin(
    message: types.Message
):
    user_id = message.from_user.id
    chat_id = message.chat.id
    
    if user_id not in config.admin:
        return
    
    if chat_id != admin_chat:
        return
    
    top = database_managment.top_bank()
    text = ""
    
    for user_id, bank in top:
        try:
            chatmember: types.ChatMember = await message.bot.get_chat_member(chat_id=user_id, user_id=user_id)
            text += f"{chatmember.user.get_mention(as_html=True)}: {bank}\n"
        except:
            text += f"{user_id}: {bank}\n"
        
    await message.reply(text, parse_mode="HTML")
    
async def top_balance_for_admin(
    message: types.Message
):
    user_id = message.from_user.id
    chat_id = message.chat.id
    
    if user_id not in config.admin:
        return
    
    if chat_id != admin_chat:
        return
    
    top = database_managment.top_balance()
    text = ""
    
    for user_id, bank in top:
        try:
            chatmember: types.ChatMember = await message.bot.get_chat_member(chat_id=user_id, user_id=user_id)
            text += f"{chatmember.user.get_mention(as_html=True)}: {bank}\n"
        except:
            text += f"{user_id}: {bank}\n"
        
    await message.reply(text, parse_mode="HTML")
 
list_status = ["left", "kicked", "banned"]
          
async def delete_in_database(
    message: types.Message
):
    if not message.new_chat_member or  message.new_chat_member.status not in list_status: return
    
    chat_id = message.chat.id
    user_id = message.new_chat_member.user.id
    result = database_managment.delete_in_chat(user_id, chat_id)
    
    if not result: return
  
async def top_coffers(
    message: types.Message
):
    chat_id = message.chat.id
    top = database_managment.top_chat_balance()
    text = "*Топ казн:*\n"
    checker = 0
    numb = 0
    for id, balance in top:
        numb += 1
        try:
	        chat = (await message.bot.get_chat(id))
	        name = html.escape(chat.title)
	        if numb in [1, 2, 3]:
	            link = chat.invite_link
	            if chat.username:
	                link = f"tg://resolve?domain={chat.username}"
	            name2 = f"[{name}]({link})"
        except:
	        database_managment.delete_chat(id)
	        checker = 1
        text += f"{name2} : *{strings.beautify_number(balance)}*\n"
    if checker > 0:
        return await top_coffers(message)
    await message.reply(text, parse_mode="Markdown", disable_web_page_preview=True)
    
async def all_chat(
    message: types.Message
):
    user_id = message.from_user.id
    if user_id not in config.admin: return
    chats = database_managment.show_sum_chat()
    text = "*Чаты:*\n"
    for id in chats:
        chat_id = id[0]
        try:
	        chat = (await message.bot.get_chat(chat_id))
	        name = html.escape(chat.title)
	        link = chat.invite_link
	        if chat.username:
	            link = f"tg://resolve?domain={chat.username}"
	        name2 = f"[{name}]({link})"
        except:
	        database_managment.delete_chat(chat_id)
	        checker = 1
        text += f"*{name2}*\n"
        
    await message.reply(text, parse_mode="Markdown", disable_web_page_preview=True)
    
async def stats(
    message: types.Message
):
    sum_players = database_managment.show_all_players()
    sum_chats = len(database_managment.show_sum_chat())
    await message.reply(f"📊На данный момент в MAgames:\n👤 {strings.beautify_number(sum_players)} пользователей\n💬 {strings.beautify_number(sum_chats)} чатов")
