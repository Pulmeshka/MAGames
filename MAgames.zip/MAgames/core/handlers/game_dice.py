from aiogram import types
from ..utils import database_managment, strings
from asyncio import sleep

async def send_dice(
    message: types.Message
):
    if len(message.text.split()) < 3:
        return await message.reply('Проверьте написание команды❌')

    user_id = message.from_user.id
    balance = database_managment.get_balance(user_id)
    bet =  strings.to_int(message.text.split()[2])
    if bet == 'nan' or bet < 0:
        return await message.reply('Не вижу ставки❌')

    numb = strings.to_int(message.text.split()[1])
    if numb == 'nan' or numb < 1 or numb > 6:
        return await message.answer('Число должно быть от 1 до 6')

    bet = round(bet)
    if balance < bet:
        return await message.reply('Недостаточно денег❌')

    balance -= bet
    database_managment.switch_balance(user_id, balance)

    msg = await message.answer_dice('🎲')
    await sleep(4)
    dice = msg.dice.value
    rating = database_managment.get_rating(user_id)
    if dice == numb:
        balance += bet*4
        rating += 0.3
        database_managment.switch_rating(user_id, round(float(rating), 1))
        database_managment.switch_balance(user_id, balance)
        return await message.reply(f'Ты угадал, твой приз🥳: {strings.beautify_number(bet*4)} монет!')

    rating -= 0.1
    database_managment.switch_rating(user_id, round(float(rating), 1))
    await message.reply('Ты проиграл🥲')
