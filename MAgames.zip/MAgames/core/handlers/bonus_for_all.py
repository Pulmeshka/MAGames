from aiogram import types
from ..utils import database_managment, strings
from .. import config

async def bonus_for_players(
    message: types.Message
):
    user_id = message.from_user.id
    if user_id not in config.admin:
        return
    try:
        bonus = strings.to_int(message.text.split()[1])
    except IndexError:
        return await message.reply('-')
    try:
        result = database_managment.bonus_all(bonus)
    except UnboundLocalError:
        await message.reply("<i>UnboundLocalError: cannot access local variable 'bonus' where it is not associated with a value</i>")
    if result is not True:
        return await message.reply("Что-то пошло не так")
    await message.reply(f"Всем был выдан бонус в размере: {strings.beautify_number(bonus)} монет")
    await message.bot.send_message(config.chat_admin, f'Всем был начислен бонус в размере {strings.beautify_number(bonus)} монет!')
