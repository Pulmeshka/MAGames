from ..utils import strings, database_managment
import sqlite3
from aiogram import types
from aiogram import exceptions
from asyncio import sleep

async def newsletter_in_chats(
    message: types.Message
):
    chat_id = message.chat.id
    user_id = message.from_user.id
    vip = database_managment.get_vip(user_id)
    if vip < 4: return
    if not message.reply_to_message: return
    text = message.reply_to_message.html_text
    chats = list(map(lambda x: x[0], database_managment.show_sum_chat()))
    for chat in chats:
        print(chat)
        try:
            if message.reply_to_message.forward_from_chat:
                await message.reply_to_message.forward(chat)
            else:
                await message.bot.send_message(chat, text, parse_mode="HTML")
        except:
            database_managment.delete_chats(chat)
        await sleep(2)
    await message.reply("Успешно!")
    
async def if_bot_leave(
    update: types.ChatMemberUpdated
):
    print(update.new_chat_member.status)
    if update.new_chat_member.status not in ["kicked", "banned", "left"]: return
    print(2)
    chat_id = update.chat.id
    print(chat_id)
    result = database_managment.delete_chats(chat_id)
    if result:
        print(result)
    print(3)