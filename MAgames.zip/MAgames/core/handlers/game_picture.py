from aiogram import types
from ..utils import database_managment, strings
from random import choice, randint
from asyncio import sleep

name_list = ['яблоко', 'апельсин', 'карандаш', 'ручка', 'стол', 'дракон', 'картина', 'рисунок', 'кофе', 'чай', 'демон', 'купальник', 'подарок', 'цветы', 'цепь']

picture_name = {}

timer_game = {}

sum_chat = {}

bonus = randint(200, 2000)

async def timer(
    message: types.Message
):
    chat_id = message.chat.id
    timer_game[chat_id] = 0
    while True:
        await sleep(1)
        if chat_id not in timer_game: break
        timer_game[chat_id] += 1
        if chat_id not in timer_game: break
        if timer_game[chat_id] == 300:
            message.text = 'Время вышло, игра окончена\nЕсли хотите продолжить, напишите "!картинки"'
            await send_picture(message)
            break

async def send_picture(
  message: types.Message
):
    chat_id = message.chat.id
    select_picture = choice(name_list)
    if chat_id not in picture_name:
        picture_name[chat_id] = select_picture
        sum_chat[chat_id] = 0
        await message.answer_photo(types.InputFile(f"core/picture/{select_picture}.jpg"))
        return await timer(message)
    if len(message.text.split()) > 5:
        if message.text.split()[5] == 'достигла':
            await message.reply(f'Отлично, ты получаешь {strings.beautify_number(bonus)} монет за правильный ответ!')
    if message.text.lower() not in name_list:
        if len(message.text.split()) < 2:
            message.text = 'Игра завершена!'
        picture_name.pop(chat_id)
        if chat_id in timer_game:
            timer_game.pop(chat_id)
        sum_chat.pop(chat_id)
        return await message.answer(message.text)
    picture_name[chat_id] = select_picture
    user_id = message.from_user.id
    balance = database_managment.get_balance(user_id)
    database_managment.switch_balance(user_id, balance+bonus)
    await message.reply(f'Отлично, ты получаешь {strings.beautify_number(bonus)} монет за правильный ответ!')
    await message.answer_photo(types.InputFile(f"core/picture/{select_picture}.jpg"))

async def try_picture(
    message: types.Message
):
    chat_id = message.chat.id
    if chat_id not in picture_name: return
    if message.text.lower() != picture_name[chat_id]: return
    sum_chat[chat_id] += 1
    if sum_chat[chat_id] > 9:
        message.text = 'Игра была завершена\nЕсли хотите продолжить, напишите "!картинки"'
    await send_picture(message)
