from ..utils import strings, database_managment
from aiogram import types

def shop_buttons_generator(user_id):
    shop_buttons = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton("НАПИШИ ЧЁТ", callback_data=f"chest {user_id}")]
        ]
    )
    return shop_buttons


async def show_shop(message: types.Message):
    if hasattr(message, "message"):
        query = message
        message = query.message
        message.from_user = query.from_user
        message.data = query.data
        await query.answer()
    user_id = message.from_user.id
    if len(message.text.split()) < 2:
        return await message.reply(f"Прилавок:\n❌ЗАКРЫТО❌")
    if user_id != int(message.data.split()[1]):
        return
    await message.edit_text(
        f"Прилавок:\n", reply_markup=shop_buttons_generator(user_id)
    )

