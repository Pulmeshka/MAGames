from aiogram import types
import sqlite3
from ..utils import strings, database_managment
from .. import config

sum = 100

async def look_referral(
    message: types.Message
):
    global sum
    if message.chat.type != "private": return
    user_id = message.from_user.id
    if len(message.text.split()) < 2:
        return await message.reply("Приветствую тебя!\n/help - ознакомься со всем!")
    referral = int(message.text.split()[1])
    check = database_managment.get_referral(user_id)
    if check != 0:
        return await message.reply("Ты уже переходил по реферальной ссылке!")
    bank_referral = strings.to_int(database_managment.get_bank(referral))
    if referral == user_id:
        return await message.reply("Приветствую тебя!\n/help - ознакомься со всем!")
    if bank_referral == "nan" or bank_referral is None:
        return await message.reply("Приветствую тебя!\n/help - ознакомься со всем!")
    if referral in config.admin: sum=4
    bank = database_managment.get_bank(user_id)
    bank += sum
    bank_referral += sum
    invited = database_managment.get_invited(referral) + 1
    database_managment.trade_bank(referral, bank_referral)
    database_managment.trade_bank(user_id, bank)
    database_managment.switch_referral(user_id, referral)
    database_managment.switch_invited(referral, invited)
    await message.reply("Приветствую тебя!\n/help - ознакомься со всем!")
    await message.reply(f"Вы перешли по реф-ссылке!\nВы получили {sum} облигаций.\nКоманда !банк в лс с ботом.")
    try:
        await message.bot.send_message(referral, f"Кто то пришел в бота по Вашей реф-ссылке!\nВы получили {sum} облигаци.\nКоманда !банк в лс с ботом.")
    except:
        pass
        
async def referral_link(
    message: types.Message
):
    global sum
    if message.chat.type != "private": return
    user_id = message.from_user.id
    if user_id in config.admin: sum=200
    await message.bot.send_message(user_id, f"Отправьте сообщение другу, когда он перейдет по ссылке и нажмет СТАРТ вы оба получите по {sum} облигаций!")
    await message.bot.send_message(user_id, f'Крутой игровой бот ждёт тебя / перейди по ссылке и получи {sum} облигаций!\n\nhttps://t.me/MAGamesBOT?start={user_id}')
