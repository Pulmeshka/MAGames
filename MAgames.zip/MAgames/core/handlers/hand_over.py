from aiogram import types
from ..utils import database_managment
              
async def pay_coin(message: types.Message):  
    user_id = message.from_user.id
    name = message.from_user.full_name
    user = message.from_user.username
    if not message.reply_to_message:
        await message.answer('ты не ответил на сообщение')
        return
    player_id = message.reply_to_message.from_user.id
    name2 = message.reply_to_message.from_user.full_name
    user2 = message.reply_to_message.from_user.username
    if message.reply_to_message.from_user.is_bot:
        await message.answer('❌')
        return
    if player_id == user_id:
        await message.answer('а ловко ты это придумал')
        return
    try:     
        suma = message.text.split()[1]
        try:
            suma = int(suma)
            coin = database_managment.get_balance(user_id)
            player_coin = database_managment.get_balance(player_id)
            coin = int(coin)
            player_coin = int(player_coin)
            if suma > coin:
                await message.answer('недостаточно денег❌')
                return
            limits = database_managment.get_limit(user_id)
            vip = database_managment.get_vip(user_id)
            if limits < suma and vip < 3:
                return await message.reply('<b>Дружище</b>, у тебя не хватает лимита!', parse_mode='HTML')
            coin -= suma
            player_coin += suma
            database_managment.switch_balance(user_id, coin)
            database_managment.switch_balance(player_id, player_coin)
            try:
                namet = name2
            except:
                namet = '.'
            await message.reply(f'*{namet}* получил *{suma}* монет от *{name}*', parse_mode='Markdown')
        except ValueError:
            await message.answer('сумма должна быть числом')
    except IndexError:
        await message.answer('ты не ввел сумму')
        