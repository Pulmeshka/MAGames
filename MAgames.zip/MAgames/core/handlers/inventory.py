from ..utils import strings, database_managment
from aiogram import types

async def show_inventory(
    message: types.Message
):
    user_id = message.from_user.id
    await message.reply(
        "Инвентарь:\n"
        f"⌛Скоро..."
    )