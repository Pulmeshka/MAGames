from ..utils import strings, database_managment
from aiogram import types, Dispatcher
from asyncio import sleep
import random

words_list = ['мешок', 'подоконник', 'роль', 'честь', 'смелость', 'храбрость', 'объятья', 'любовь', 'романтика', 'эрудиция', 'пара','окно', 'лес', 'дорога', 'машина', 'земля', 'город', 'село', 'человек', 'больница', 'палата', 'парта', 'школа', 'вызов', 'взрыв', 'стол', 'фонарь', 'нога', 'рука', 'глаз', 'тарелка', 'вилка', 'палка', 'ручка', 'карандаш', 'пенал', 'очки', 'калькулятор', 'язык', 'дом', 'квартира', 'кухня', 'кровать', 'подушка', 'кот', 'семь', 'ноль', 'мост', 'река', 'озеро', 'вечер', 'ветер', 'кровь', 'утро', 'обед', 'время', 'жизнь', 'смерть', 'телевизор', 'тело', 'орган', 'музыка', 'песня', 'лифт', 'лирика', 'глобус', 'страна', 'космос', 'звезда', 'луна', 'солнце', 'девушка', 'ребёнок', 'семья', 'тетрадь', 'маркер', 'пара', 'парк', 'любовь', 'счастье', 'грусть', 'дело', 'адвокат', 'судья', 'прокурор', 'прокуратура', 'полиция', 'закон', 'власть', 'президент', 'министр', 'здоровье', 'врач', 'белый', 'снег', 'лето', 'весна', 'зима', 'персик', 'вишня', 'яблоко', 'поэзия', 'эксперт', 'москвич', 'письмо', 'поэма', 'концерт', 'гвардия', 'бинокль', 'цитрус', 'зерно', 'Бабушка', 'лис', 'заяц', 'берег', 'чума', 'песок', 'парень', 'парламент', 'деревня', 'скорая', 'параллель', 'мозг', 'мышь', 'каскадёр', 'корреспондент', 'теплица', 'фрукты', 'корзина', 'золушка', 'клубника', 'перевод', 'перенос', 'практика', 'офицер', 'оливье', 'динозавр', 'птеродактиль', 'астрономия', 'иерархиях', 'анатомия', 'абрикос', 'олень', 'сакура', 'колено','огород','автомобиль','трактор','компьютер','бинокль']
list = []
async def words_for_chat():
    global list
    list = []
    for i in range(1, 15):
        word = random.choice(words_list)
        if word not in list:
            list.append(word)
    return list

async def get_chat_state(chat_id):
    return Dispatcher.get_current().current_state(chat=chat_id,user=chat_id)


async def get_game(chat_id):
    state = await get_chat_state(chat_id)
    data = await state.get_data()
    if "words" not in data:
        return -1
    return data["words"]

async def new_game(chat_id):
    if (await get_game(chat_id)) != -1:
        return -1
    state = await get_chat_state(chat_id)
    list = await words_for_chat()
    await state.update_data(
        {
            "words": {
                "list" : list,
                "players" : {}
            }
        }
    )
    
async def text_generator(chat_id):
    game = await get_game(chat_id)
    if game == -1:
        return -1
    list = game["list"]
    text_words = "Буквы:\n"
    list_litters = []
    text = "\n\nПодсказки:\n"
    for word in list:
        string = word
        length = len(string)
        half = int(length / 2)
        text += "{0}, ".format(string[0]+("*"*len(string[1:-1]))+string[-1])
        for litters in word[1:-1]:
            if litters not in list_litters:
                list_litters.append(litters.upper())
                
    num = 0
    random.shuffle(list_litters)
    for lit in list_litters:
        num += 1
        if num == 8:
            text_words += f"\n{lit}   "
            num = 0
        else:
            text_words += f"{lit}   "
    text_words += text
    return text_words
    
async def new_player(chat_id, player_id, name):
    game = await get_game(chat_id)
    if game == -1:
        return -1
    elif player_id in game["players"]:
        game["players"][player_id]["sum"] += 15
    else:
        game["players"][player_id] = {
            "sum" : 15,
            "name" : name
        }
    state = await get_chat_state(chat_id)
    await state.update_data(
        {
            "words": game
        }
    )
    return True
    
timer_game = {}
    
async def the_and_game(
    chat_id
):
    game = await get_game(chat_id)
    text = "Игра завершена!\n"
    if len(game["players"]) > 0:
        for player in game["players"]:
            balance = database_managment.get_balance(player) + game["players"][player]["sum"]
            database_managment.switch_balance(player, balance)
            text += f"{game['players'][player]['name']} {game['players'][player]['sum']} монет\n"
    text += "\nОстались слова:\n"
    num = 0
    for word in game["list"]:
        num += 1
        if num == 1:
            text += word
        else:
            text += f", {word}"
            
    await remove_game(chat_id)
    timer_game.pop(chat_id)
    return text

async def remove_word(chat_id, word):
    game = await get_game(chat_id)
    if game == -1: return -1
    
    game["list"].remove(word)
    
    state = await get_chat_state(chat_id)
    await state.update_data(
        {
            "words": game
        }
    )
    return True

async def remove_game(chat_id):
    game = await get_game(chat_id)
    if game == -1:
        return -1

    state = await get_chat_state(chat_id)

    async with state.proxy() as data:
        del data["words"]

    return True

async def timer(
    message: types.Message
):
    chat_id = message.chat.id
    timer_game[chat_id] = 0
    while True:
        await sleep(1)
        if chat_id not in timer_game:
            text = await the_and_game(chat_id)
            await message.bot.send_message(chat_id, text)
            break
        timer_game[chat_id] += 1
        if chat_id not in timer_game: break
        if timer_game[chat_id] == 30:
            text = await the_and_game(chat_id)
            await message.bot.send_message(chat_id, text)
            break
    
async def start_and_end(
    message: types.Message
):
    chat_id = message.chat.id
    game = await get_game(chat_id)
    if game == -1:
        await new_game(chat_id)
        text = await text_generator(chat_id)
        await message.reply(f"Игра начата!\n\n{text}")
        return await timer(message)
    text = await the_and_game(chat_id)
    await message.bot.send_message(chat_id, text)
    
async def word(
    message: types.Message
):
    user_id = message.from_user.id
    chat_id = message.chat.id
    game = await get_game(chat_id)
    if game == -1: return
    list = game["list"]
    if message.text[1:].lower() not in list: return
    chatmember: types.ChatMember = await message.chat.get_member(user_id)
    name = chatmember.user.full_name
    await remove_word(chat_id, message.text[1:].lower())
    await new_player(chat_id, user_id, name)
    list.remove(message.text[1:].lower())
    if len(list) < 1: 
        text = await the_and_game(chat_id)
        return await message.reply(text)
    text = await text_generator(chat_id)
    await message.reply(f"Угадывает слово:\n{name} +50\n\n{text}")