from aiogram import types

async def donate_message(
    message: types.Message
):
    chat_id = message.chat.id
    await message.bot.send_message(chat_id, "Привет, вижу у тебя проснулось желание посмотреть что тут, напиши команду /help в гайде найдёшь донаты")