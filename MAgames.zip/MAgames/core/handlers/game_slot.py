from aiogram import Bot, Dispatcher
import sqlite3
from ..utils import strings, database_managment
import random
from asyncio import sleep
from aiogram import exceptions

emoji_pack = [
    ["🎟", "🎫", "🎗", "🎪", "🎭"],
    ["🎤", "🎸", "🪕", "🎻", "🎷"],
    ["⚽️", "🏀", "🥎", "⚾️", "🎾"],
    ["🚝", "🚄", "🚅", "🚈", "🚞"],
    ["🌇", "🌆", "🏙", "🌃", "🌌"],
    ["📒", "📕", "📗", "📘", "📙"],
    ["🟠", "🟡", "🟢", "🔵", "🟣"],
    ["🟧", "🟨", "🟩", "🟦", "🟪"],
    ["🕐", "🕑", "🕒", "🕓", "🕔"],
    ["🧚", "👒", "🧣", "🐴", "🦄"]
]


async def slot(message):
    chat_id = message.chat.id
    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()
    user_id = message.from_user.id
    if len(message.text.split()) >= 2:
        bet = strings.to_int(message.text.split(maxsplit=1)[1].replace(" ", ""))
        if bet == "nan":
            return await message.reply("Введите ставку правильно!")
        bet = round(bet)
        balance = database_managment.get_balance(user_id)
        if bet <= 0:
        	return await message.reply("Укажи ставку в нормальном формате!")
        if balance >= bet:
            balance -= bet
            database_managment.switch_balance(user_id, balance)
            emoji_list = random.choice(emoji_pack)

            emoji_one = random.choice(emoji_list)
            emoji_two = random.choice(emoji_list)
            emoji_three = random.choice(emoji_list)
                
            slot_name ="🎰Слот-машина🎰\n"
            result = f"\t\t\t\t\t\t{emoji_one} : {emoji_two} : {emoji_three}\n"
            if emoji_one == emoji_two == emoji_three:
                win = bet
                type = "Линия!"
                bet = win*3
                if emoji_one == "🦄":
                    bet = win*100
                    type = "!!!ДЖЭКПОТ!!!"
                result += type
            elif emoji_one == emoji_two:
                result += "Пара!"
                bet = bet*2
            elif emoji_two == emoji_three:
                result += "Возврат 50%!"
                bet = round(bet/2)
            else:
                result += "Проигрыш..."
                bet = 0

            rating = database_managment.get_rating(user_id)
            if bet:
                database_managment.switch_rating(user_id, round(float(rating + 0.3), 1))
            else:
                rating -= 0.1
                database_managment.switch_rating(user_id, round(float(rating), 1))

            balance += bet
            
            msg = await message.reply(slot_name + f"\t\t\t\t\t\t{emoji_one} : 🌫 :🌫 ")
            try:
                await sleep(2)
                await msg.edit_text(slot_name + f"\t\t\t\t\t\t{emoji_one} : {emoji_two} :🌫 ")
                await sleep(2)
                database_managment.switch_balance(user_id, balance)
                await msg.edit_text(slot_name + result + f"\nТы получаешь: {strings.beautify_number(bet)}")
            except exceptions.MessageCantBeEdited:
                pass

        else:
        	await message.reply("У тебя нет столько!")