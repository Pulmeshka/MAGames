from aiogram import types, exceptions
from ..utils import strings, database_managment
from .. import config


async def set_balance(message: types.Message):
    user_id = message.from_user.id
    if user_id not in config.admin:
        return
    if message.reply_to_message:
        try:
            player_id = message.reply_to_message.from_user.id
            balance = strings.to_int(message.text.split()[1])
        except IndexError or UnboundLocalError:
            return await message.reply('-')
    if len(message.text.split()) > 2:
        player_id = strings.to_int(message.text.split()[1])
        balance = strings.to_int(message.text.split()[2])
    try:    
        result = database_managment.switch_balance(player_id, balance)
    except UnboundLocalError:
                return await message.reply('-')
    if result is not True:
        return await message.reply("Что-то не так")
    await message.reply(
        f"Баланс игрока изменен на: {strings.beautify_number(balance)} монет ✅"
    )

async def set_rating(message: types.Message):
    user_id = message.from_user.id
    if user_id not in config.admin:
        return
    if message.reply_to_message:
        try:
            player_id = message.reply_to_message.from_user.id
            balance = strings.to_int(message.text.split()[1])
        except IndexError or UnboundLocalError:
            return await message.reply('-')
    if len(message.text.split()) > 2:
        player_id = strings.to_int(message.text.split()[1])
        balance = strings.to_int(message.text.split()[2])
    try:
        result = database_managment.switch_rating(player_id, balance)
    except UnboundLocalError:
        return await message.reply('-')
    if result is not True:
        return await message.reply("Что-то не так")
    await message.reply(
        f"Рейтинг игрока изменен на: {strings.beautify_number(balance)}"
    )


async def set_bank(message: types.Message):
    user_id = message.from_user.id
    if user_id not in config.admin:
        return
    if message.reply_to_message:
        try:
            player_id = message.reply_to_message.from_user.id
            bank = strings.to_int(message.text.split()[1])
        except IndexError or UnboundLocalError:
            return await message.reply('-')
    if len(message.text.split()) > 2:
        player_id = strings.to_int(message.text.split()[1])
        bank = strings.to_int(message.text.split()[2])
    try:
        result = database_managment.trade_bank(player_id, bank)
    except UnboundLocalError:
        return await message.reply('-')
    if result is not True:
        return await message.reply("Что-то не так")
    await message.reply(
        f"Банк игрока изменен на: {strings.beautify_number(bank)} монет"
    )


async def set_lvl(message: types.Message):
    user_id = message.from_user.id
    if user_id not in config.admin:
        return
    if message.reply_to_message:
        try:
            player_id = message.reply_to_message.from_user.id
            vip = strings.to_int(message.text.split()[1])
        except IndexError or UnboundLocalError:
            return await message.reply('-')
    if len(message.text.split()) > 2:
        player_id = strings.to_int(message.text.split()[1])
        vip = strings.to_int(message.text.split()[2])
    try:
        result = database_managment.switch_level(player_id, vip)
    except UnboundLocalError:
        return await message.reply('-')
    if result is not True:
        return await message.reply("Что-то не так")
    await message.reply(f"Вип игрока изменен на: {vip} level")


async def set_uah_balance(message: types.Message):
    user_id = message.from_user.id

    if user_id not in config.admin:
        return

    if not message.reply_to_message and len(message.text.split()) < 3:
        return await message.reply("ответ на сообщение: /set_im IM\n\nпо айди: /set_im ID IM")

    if message.reply_to_message:
        try:
            player_id = message.reply_to_message.from_user.id
            uah = strings.to_float(message.text.split()[1])
        except IndexError:
            return await message.reply("ответ на сообщение: /set_im IM\n\nпо айди: /set_im ID IM")
    else:
        try:
            player_id = strings.to_int(message.text.split()[1])
            uah = strings.to_float(message.text.split()[2])
        except:
            return await message.reply("ответ на сообщение: /set_im IM\n\nпо айди: /set_im ID IM")

    database_managment.set_player_uah(
        player_id,
        uah
    )

    await message.reply("Баланс ИМ было изменено")


async def add_to_uah_balance(message: types.Message):
    user_id = message.from_user.id

    if user_id not in config.admin:
        return

    if not message.reply_to_message and len(message.text.split()) < 3:
        return await message.reply("ответ на сообщение: /set_im IM\n\nпо айди: /set_im ID IM")

    if message.reply_to_message:
        try:
            player_id = message.reply_to_message.from_user.id
            uah = strings.to_float(message.text.split()[1])
        except IndexError:
            return await message.reply("ответ на сообщение: /set_im IM\n\nпо айди: /set_im ID IM")
    else:
        try:
            player_id = strings.to_int(message.text.split()[1])
            uah = strings.to_float(message.text.split()[2])
        except:
            return await message.reply("ответ на сообщение: /set_im IM\n\nпо айди: /set_im ID IM")
    database_managment.add_player_uah(
        player_id,
        uah
    )

    await message.reply("На баланс были добавлены ИМ")
