import sqlite3
from ..utils import strings, database_managment
from .. import middlewares
from datetime import timedelta
import time

async def show_balance(message):
    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()
    user_id = message.from_user.id
    balance = database_managment.get_balance(user_id)
    await message.reply(f"Ваш баланс:\n<code>{strings.beautify_number(balance)}</code> монет", parse_mode="HTML")