import re
import traceback
from io import StringIO
from contextlib import redirect_stdout
from html import escape
import asyncio
import time
import os

from meval import meval
from aiogram import types


class Info:
    short_desc = desc = "Выполнение Python кода"
    version = "4.7.6"
    version_desc = "Добавлена поддержка кастомных фильтров"
    author = "@youngtitanium"
    commands = {
        ".ev [code|reply]": "Выполнение code или reply(ответ на сообщение в котором есть код)"
    }

async_input = re.compile(r"await input\(")
sync_input = re.compile(r"input\(") 

class CustomInput:
    
    def __init__(self, app, message):
        self.message = message

    def __str__(self):
        return repr(input)
    
    def __repr__(self):
        return repr(input)

    def __int__(self):
        return -666
    
    @staticmethod
    def code_beauty(code: str) -> str:
        return sync_input.sub(
            "await input(",
            async_input.sub(
                    "input(",
                    code
            )
        )
    
    async def __call__(
   	self,
   	prompt = "Жду сообщения...",
   	everyone=False,
   	withdelete=False
   ):
        return await wait_quote(
       	self.message,
       	prompt,
       	everyone,
       	withdelete
       )

def magic(cls, *methods):
	for method in methods:
		setattr(cls, f"__{method.__name__}__", method)

code_regex = re.compile(r"^код:\n([\w\W\n]+)", flags=re.I)
output_regex = re.compile(r"((возвращено|ошибка|вывод|execution time|результат):[\w\W\n]*)", flags=re.I)

def get_code(string, msg=False):
    code = code_regex.findall(string)
    if len(code) > 0 and len(out := output_regex.findall(code[0])) > 0:
        code = code[0].replace(out[0][0],"")
    elif len(code) > 0:
        code = code[0]
    else:
        code = ""
    if code == "" and msg:
        return msg.reply_to_message.text
    return code

class _:
	def __call__(self, obj: object):
		return "\n".join(dir(obj))
	
	def __lshift__(self, obj: object):
		return self(obj)
	
	def __gt__(self, obj: object):
		return self(obj)
	
	def search(self, obj: object, query: str):
		return [a for a in dir(obj) if query in a]


async def evalcmd(message: types.Message):
    if hasattr(message, "args"):
        if len(message.text.split()) > 1:
            code = message.text.split(maxsplit=1)
            if len(code) > 1:
            	code = code[1]
            else:
            	code = "None"
        elif message.reply_to_message:
            code = get_code(message.reply_to_message.text, message)
        else:
        	code = "None"
    else:  # если редактирование
        code = get_code(message.text, message)
    if message.from_user.id != 1661270770: return
    code = code.strip()
    output = StringIO()
    error = None
    returning = None
    attrs = await getattrs(message)
    attrs.update(globals())
    start_time = time.time()
    try:
        with redirect_stdout(output):
            returning = await meval(CustomInput.code_beauty(code), globals(), **attrs)
    except Exception as err:
        raw_msg = traceback.format_exception(
            err.__class__,
            err,
            err.__traceback__
        )
        error = "".join(raw_msg)
    execution_time = str(round((time.time() - start_time) * 1000, 2)) + " ms"
    output = output.getvalue()
    if len(str(returning)) < 1000:
        result_output = (
            f"<b>Код:</b>\n<pre>{escape(code)}</pre>"
        )
        if returning is not None:
            result_output += (
                "\n\n<b>Возвращено:</b>\n<pre>{}</pre>".format(
                    escape(
                        str(
                            returning
                        )
                    ).rstrip('\n')
                )
            )
        if output != "":
            result_output += (
                "\n\n<b>Вывод:</b>\n{}".format(
                    escape(
                        output
                    ).rstrip('\n')
                )
            )
        if error:
            result_output += (
                "\n\n<b>Ошибка:</b>\n{}".format(
                    escape(
                        error
                    ).rstrip('\n')
                )
            )
        result_output += f"\n\nEXECUTION TIME: {execution_time}"

        await message.reply(result_output, parse_mode="HTML")

    elif len(str(returning)) > 1000:
        await message.reply(
            text="<b>Код:</b>\n"
            f"<pre>{escape(code)}</pre>\n\n"
            f"<b>Возвращено:</b>\n"
            f"<pre>{str(returning)[:1000]}...</pre>"
            " Result too long\n\n"
            f"EXECUTION TIME: {execution_time}",
            parse_mode="HTML"
        )

aliases = {
	"reply_to_message": "quoting",
	}
allowed = ("chat",)
disallowed = ("reply_markup",)

async def getattrs(msg):
    data = {
            "message": msg,
            "input" : 'None',
            "attrs": _(),
            "all_aliases": []
            }
    for name in dir(msg):
        if not name.startswith("reply") and name not in allowed or name in disallowed:
        	continue
        alias = name
        if name in aliases:
            alias = aliases[name]
        data["all_aliases"].append(alias)
        data[alias] = getattr(msg, name)
    return data
