from aiogram import types
from ..utils import database_managment, strings
import os
from json import dump, load
 
price_rp = 100_000

if not os.path.exists("rp.luke"):
    all_roleplays = {}
    with open("rp.luke", "w") as file:
        dump(all_roleplays, file)
else:       
    with open("rp.luke", "r") as f:
        all_roleplays = load(f)
    
if not isinstance(all_roleplays, dict):
    all_roleplays = {}
    
trigger_list = []
for user_id, roleplays in all_roleplays.items():
    trigger_list += list(roleplays.keys())
    
    
async def del_roleplay(
    message: types.Message
):
    user_id = str(message.from_user.id)
    balance = database_managment.get_balance(user_id)
    if len(message.text.split()) > 2: return 
    if len(message.text.split()) < 2:
        return await message.reply("Вы что-то забыли!")
    with open("rp.luke", "r") as f:
        roleplay_dirt = load(f)
        
    if user_id not in roleplay_dirt:
        return await message.reply("У вас нет рп!")
        
    trigger = message.text.split()[1].lower()
    if trigger not in roleplay_dirt[user_id]:
        return await message.reply("У вас нет такого рп!")
    
    roleplay_dirt[user_id].pop(trigger)
    
    with open("rp.luke", "w") as f:
        dump(roleplay_dirt, f)
        
    await message.reply("Рп успешно удалено!")

async def add_roleplay(
    message: types.Message
):
    user_id = str(message.from_user.id)
    balance = database_managment.get_balance(user_id)
        
    with open("rp.luke", "r") as f:
        roleplay_dirt = load(f)
        
    if len(message.text.split()) < 2:
        if user_id not in roleplay_dirt:
            return await message.reply("У вас нет рп!")
        numb = 0
        text = "Ваши рп:"
        for i in roleplay_dirt[user_id]:
            numb += 1
            text += f"\n{numb}: {i.capitalize()}"
        return await message.reply(text)
    if balance < price_rp:
        return await message.reply(f"Стоимость личной рп: {price_rp}")
        
    if message.entities:
        if message.entities[0]["type"] == "url": 
            return await message.reply("В рп не должно быть ссылки!")
    
    if len(message.text.split(maxsplit=1)) > 40:
        return await message.reply("Максимальная длинна рп,: 40 символов")
    
    trigger = message.text.split()[1].lower()
    
    if len(message.text.split()) < 3:
        return await message.reply("Ты что-то забыл!")
    text = message.text.split(maxsplit=2)[2]
    if user_id not in roleplay_dirt:
        roleplay_dirt[user_id] = {}
    roleplay_dirt[user_id][trigger] = text
    
    balance -= price_rp
    database_managment.switch_balance(user_id, balance)
    with open("rp.luke", "w") as f:
        dump(roleplay_dirt, f)
    trigger_list.append(trigger)
    await message.reply(f"Вы успешно купили рп, за {price_rp} монет!")
    
async def used_roleplay(
    message: types.Message
):
    if not message.reply_to_message: return
    user_id = str(message.from_user.id)
    with open("rp.luke", "r") as f:
        roleplay_dirt = load(f)
    trigger = message.text.lower()
    if user_id not in roleplay_dirt: return
    if trigger not in roleplay_dirt[user_id]: return
    chat_id = message.chat.id
    
    user = message.from_user.get_mention(as_html=True)
    player = message.reply_to_message.from_user.get_mention(as_html=True)
    text = roleplay_dirt[user_id][trigger]
    await message.bot.send_message(chat_id, f"{user} {text} {player}", parse_mode="HTML")