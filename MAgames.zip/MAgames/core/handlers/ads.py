from ..utils import strings, database_managment
from asyncio import sleep
from aiogram import types
import os
from datetime import timedelta
from random import randint

is_blocked = {}
bank = 100
bonus = randint(5000, 50_000)

keyboardads = types.InlineKeyboardMarkup()
keyboardads.add(types.InlineKeyboardButton(text='Подписаться🤑', url='https://t.me/MAGamesNEWS'))


async def timer(
    user_id: int
):
    is_blocked[user_id] = 0
    while user_id in is_blocked:
        await sleep(1)
        is_blocked[user_id] += 1
        if is_blocked[user_id] == 3600:
            is_blocked.pop(user_id)
            
async def show_ads(
    message: types.Message
):
    user_id = message.from_user.id
    chat_id = message.chat.id
    text = '*Подпишись на оффициальный канал бота и получай новости об обновлениях*'
    await message.bot.send_message(chat_id, text, parse_mode="Markdown", reply_markup=keyboardads)
    if user_id in is_blocked:
        return await message.reply(f"Ты уже смотрел рекламу!\nПриходи через {strings.beautify_date(timedelta(seconds=3600-is_blocked[user_id]))}")
    opportunity = randint(1, 3)
    if opportunity == 3:
        chance = randint(3, bank)
        bank_balance = database_managment.get_bank(user_id)
        bank_balance += chance
        database_managment.trade_bank(user_id, bank_balance)
        return await message.reply(f"Ты получил: {strings.beautify_number(chance)} облигаций за просмотр рекламы!")
    balance = database_managment.get_balance(user_id) + bonus
    database_managment.switch_balance(user_id, balance)
    await message.reply(f"Ты получил: {strings.beautify_number(bonus)} монет за просмотр рекламы!")
    await timer(user_id)