from ..utils import strings
from asyncio import sleep
import sqlite3
import random
from datetime import timedelta

time_bonus = {}

async def timer(message):
    user_id = message.from_user.id
    while True:
        global time_bonus
        time_bonus[user_id] += 1
        await sleep(1)
        if time_bonus[user_id] == 1800:
            time_bonus.pop(user_id)
            break

async def take_bonus(message):
    global time_bonus
    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()
    user_id = message.from_user.id
    if user_id in time_bonus:
        
        return await message.reply(f"След. награда: {strings.beautify_date(timedelta(seconds=1800-time_bonus[user_id]))}")
    cursor.execute(
        "SELECT "
            "balance "
        "FROM "
            "players "
        "WHERE "
            "id=?",
        (
        user_id,
        )
    )
    balance = int(cursor.fetchone()[0])
    bonus = random.randint(5000, 50000)
    cursor.execute(
        "UPDATE "
            "players "
        "SET "
            "balance=?"
        "WHERE "
            "id=?",
        (
            balance + bonus,
            user_id
        )
    )
    connection.commit()
    time_bonus[user_id] = 0
    await message.reply(f"Вы получили: {strings.beautify_number(bonus)} монет!")
    await timer(message)