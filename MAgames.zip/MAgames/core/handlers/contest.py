from ..utils import database_managment, strings
import random
from aiogram import types
from asyncio import sleep
from aiogram import Dispatcher
from aiogram import exceptions

min = 50_000
max = 300_000

async def get_chat_state(chat_id):
    return Dispatcher.get_current().current_state(chat=chat_id,user=chat_id)


async def get_contest(chat_id):
    state = await get_chat_state(chat_id)
    data = await state.get_data()
    if "contest" not in data:
        return -1
    return data["contest"]

async def new_contest(chat_id, sum, athor):
    if (await get_contest(chat_id)) != -1:
        return -1
    state = await get_chat_state(chat_id)
    await state.update_data(
        {
            "contest": {
                "athor" : athor,
                "players" : [],
                "sum" : sum
            }
        }
    )

async def new_player(chat_id, player_id):
    game = await get_contest(chat_id)
    if game == -1:
        return -1
    elif player_id in game["players"]:
        return -2
    else:
        game["players"] .append(player_id)
        
    state = await get_chat_state(chat_id)
    await state.update_data(
        {
            "contest": game
        }
    )
    return 


async def remove_contest(chat_id):
    game = await get_contest(chat_id)
    if game == -1:
        return -1

    state = await get_chat_state(chat_id)

    async with state.proxy() as data:
        del data["contest"]

    return True
    
id_message = {}

async def contest_chat(
    message: types.Message
):
    if message.chat.type == "private": return
    chat_id = message.chat.id
    game = await get_contest(chat_id)
    user_id = message.from_user.id
    if game != -1:
        return await message.reply("Розыгрыш уже идёт!")
    if len(message.text.split()) < 2:
        return await message.reply("Ты забыл указать сумму!")
    sum = strings.to_int(message.text.split(maxsplit=1)[1].replace(" ", ""))
    if sum == "nan":
        return await message.reply("Здесь что-то не так")
    sum = round(sum)
    if sum < min:
        return await message.reply(f"Минимальная сумма розыгрыша {strings.beautify_number(min)}!")
    balance = database_managment.get_balance(user_id)
    if sum > balance:
        return await message.reply("У тебя недостаточно монет!")
    vip = database_managment.get_vip(user_id)
    if sum > max and vip < 2:
        return await message.reply("Твой максимум 300к\nДля увелечение тебе нужен второй вип")
    balance -= sum
    result = database_managment.switch_balance(user_id, balance)
    if result is not True:
        return await message.reply("Что-то пошло не так!")
    await new_contest(chat_id, sum, user_id)
    chatmember: types.ChatMember = await message.chat.get_member(user_id)
    name = chatmember.user.full_name
    msg = await message.bot.send_message(chat_id, f"{name} устраивает розыгрыш на {strings.beautify_number(sum)} монет\nНужно 4 участника\n", reply_markup = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Участвовать!", 
                callback_data = "join_in_contest"
            )
        ]
    ]
))
    id_message[chat_id] = msg.message_id
    await contest_timer(message)
    
async def join_in_contest(
    message: types.Message
):
    if hasattr(message, "message"):
        query = message
        message = query.message
        message.from_user = query.from_user
        await query.answer()
    chat_id = message.chat.id
    user_id = message.from_user.id
    game = await get_contest(chat_id)
    if game == -1: return
    if user_id in game["players"]: return
    if database_managment.get_balance(user_id) is None: return
    if user_id == game["athor"]: return
    await new_player(chat_id, user_id)
    chatmember: types.ChatMember = await message.chat.get_member(user_id)
    name = chatmember.user.full_name
    text = message.text
    if len(text.split("\n")) < 2:
        text += "\n"
    try:
        await message.bot.edit_message_text(f"{text}\n{name}", chat_id, id_message[chat_id], reply_markup = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Участвовать!", 
                callback_data = "join_in_contest"
            )
        ]
    ]
))
    except exceptions.MessageCantBeEdited:
        pass

async def the_end_contest(
    message: types.Message
):
    chat_id = message.chat.id
    game = await get_contest(chat_id)
    if game == -1: return
    sum = game["sum"]
    try:
        await message.bot.delete_message(chat_id, id_message.pop(chat_id))
    except exceptions.MessageToDeleteNotFound:
        pass
    await remove_contest(chat_id)
    players = game["players"]
    user_id = game["athor"]
    if len(players) < 4:
        balance = database_managment.get_balance(user_id)
        balance += sum
        database_managment.switch_balance(user_id, balance)
        return await message.bot.send_message(chat_id, "Розыгрыш не состоялся, нужно 4 участника")
    chatmember: types.ChatMember = await message.chat.get_member(random.choice(players))
    rating = database_managment.get_rating(user_id)
    database_managment.get_rating(user_id, round(float(rating+0.6), 1))
    name = chatmember.user.full_name
    msg = await message.bot.send_message(chat_id, f"В розыгрыше победил {name}...")
    for time in range(10):
        await sleep(3)
        user = random.choice(players)
        try:
            chatmember: types.ChatMember = await message.chat.get_member(user)
            name = chatmember.user.full_name
        except:
            players.remove(user)
        try:
            await msg.edit_text(f"В розыгрыше победил {name}...")
        except:
            pass
    try:
        await msg.delete()
    except exceptions.MessageToDeleteNotFound:
        pass
    winner = random.choice(players)
    chatmember: types.ChatMember = await message.chat.get_member(winner)
    name = chatmember.user.get_mention(as_html=True)
    balance = database_managment.get_balance(winner)
    balance += sum
    result = database_managment.switch_balance(winner, balance)
    if result is not True:
        return await message.bot.send_message(chat_id, "Что-то пошло не так")
    await message.bot.send_message(chat_id, f"Поздравляем {name}!!!\nЗабирай {strings.beautify_number(sum)}!")
    
    	
async def contest_timer(
    message: types.Message
):
    chat_id = message.chat.id
    timer = 0
    while True:
        timer += 1
        await sleep(1)
        if timer == 300:
            await the_end_contest(message)
            break