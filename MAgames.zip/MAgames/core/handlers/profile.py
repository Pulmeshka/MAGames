from aiogram import types
from ..utils import strings, database_managment

async def user_profile(
    message: types.Message
):
    chat_id = message.chat.id
    user_id = message.from_user.id
    name = message.from_user.get_mention(as_html=True)
    if message.reply_to_message:
        user_id = message.reply_to_message.from_user.id
        name = message.reply_to_message.from_user.get_mention(as_html=True)
        
        vip = database_managment.get_vip(user_id)
        vip_checker = database_managment.get_vip(message.from_user.id)
        
        if vip > 1:
            if vip_checker <= vip:
                return await message.reply("Профиль скрыт!")

    player = database_managment.get_player(user_id)
            
    balance = database_managment.get_balance(user_id)
    
    rait = database_managment.get_rating(user_id)
    
    invited = database_managment.get_invited(user_id)
    
    crystals = database_managment.get_kripto(user_id)
    
    theft = database_managment.get_theft(user_id)
    
    vip = database_managment.get_vip(user_id)

    await message.reply(
        text=f"Имя: {name}\n"
             f"Рейтинг: {rait}\n"
             f"VIP: {vip}\n"
             f"Пригласил(а): {invited} чел.\n"
             f"Монеты: {strings.beautify_number(balance)}\n"
             f"Кристаллы: {crystals}💎\n"
             f"Воровство: {theft}\n"
             f"ИМ👑: {strings.beautify_number(player['uah_balance'])}🔅\n"
             f"<code>{user_id}</code>",
        parse_mode="HTML")