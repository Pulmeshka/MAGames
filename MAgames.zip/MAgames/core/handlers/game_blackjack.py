from functools import wraps
from ..utils import strings, database_managment
from aiogram import Dispatcher
from aiogram import types
import random
from asyncio import sleep
from datetime import timedelta
from aiogram import exceptions


async def get_chat_state(chat_id):
    return Dispatcher.get_current().current_state(chat=chat_id,user=chat_id)


async def get_game(chat_id):
    state = await get_chat_state(chat_id)
    data = await state.get_data()
    if "blackjack" not in data:
        return -1
    return data["blackjack"]

deck_for_chat = ['2♠️', '3♠️', '4♠️', '5♠️', '6♠️', '7♠️', '8♠️', '9♠️', '10♠️', 'J♠️', 'Q♠️', 'K♠️', 'A♠️', '2♣️', '3♣️', '4♣️', '5♣️', '6♣️', '7♣️', '8♣️', '9♣️', '10♣️', 'J♣️', 'Q♣️', 'K♣️', 'A♣️', '2♥️', '3♥️', '4♥️', '5♥️', '6♥️', '7♥️', '8♥️', '9♥️', '10♥️', 'J♥️', 'Q♥️', 'K♥️', 'A♥️', '2♦️', '3♦️', '4♦️', '5♦️', '6♦️', '7♦️', '8♦️', '9♦️', '10♦️', 'J♦️', 'Q♦️', 'K♦️', 'A♦️']

async def new_game(chat_id):
    if (await get_game(chat_id)) != -1:
        return -1
    state = await get_chat_state(chat_id)
    random.shuffle(deck_for_chat)
    await state.update_data(
        {
            "blackjack": {
                "players": {},
                "deck": deck_for_chat.copy(),
                "bot" : [],
                "started": False
            }
        }
    )


async def new_player(chat_id, player_id, rate, name):
    game = await get_game(chat_id)
    if game == -1:
        return -1
    elif player_id in game["players"]:
        game["players"][player_id]["rate"] += rate
    else:
        game["players"][player_id] = {
            "rate": rate,
            "cards": [game["deck"].pop(0), game["deck"].pop(0)],
            "done": False,
            "name" : name
        }
    state = await get_chat_state(chat_id)
    await state.update_data(
        {
            "blackjack": game
        }
    )
    return game["players"][player_id]["rate"]


async def pick_card(chat_id, player_id):
    game = await get_game(chat_id)
    if game == -1:
        return -1
    elif player_id not in game["players"]:
        return -2
    game["players"][player_id]["cards"].append(game["deck"].pop(0))

    state = await get_chat_state(chat_id)

    await state.update_data(
        {"blackjack": game}
    )
    return get_cards_prize(game["players"][player_id]["cards"])

async def bot_pick_card(chat_id):
    game = await get_game(chat_id)

    if game == -1:
        return -1
        
    game["bot"].append(game["deck"].pop(0))
    
    state = await get_chat_state(chat_id)

    await state.update_data(
        {"blackjack": game}
    )
    
    return game["bot"]
    
async def remove_player(chat_id, player_id):
    game = await get_game(chat_id)

    if game == -1:
        return -1

    if player_id not in game["players"]:
        return True

    else:
        game["deck"] += game["players"][player_id]["cards"]
        del game["players"][player_id]

    state = await get_chat_state(chat_id)

    await state.update_data(
        {"blackjack": game}
    )


async def start_game(chat_id):
    game = await get_game(chat_id)

    if game == -1:
        return -1

    game["started"] = True

    state = await get_chat_state(chat_id)

    await state.update_data(
        {"blackjack": game}
    )

async def double_rate(chat_id, player_id, rate):
    game = await get_game(chat_id)

    if game == -1:
        return -1
        
    if player_id not in game["players"]:
        return -2
    game["players"][player_id]["rate"] =rate

    state = await get_chat_state(chat_id)

    await state.update_data(
        {"blackjack": game}
    )

async def get_player_cards(chat_id: int, player_id: int):
    game = await get_game(chat_id)

    if game == -1:
        return -1
    elif player_id not in game["players"]:
        return -2

    return game["players"][player_id]["cards"]


async def get_player_done(chat_id: int, player_id: int):
    game = await get_game(chat_id)

    if game == -1:
        return -1
    elif player_id not in game["players"]:
        return -2

    return game["players"][player_id]["done"]


async def set_player_done(chat_id: int, player_id: int, value: bool):
    game = await get_game(chat_id)

    if game == -1:
        return -1
    elif player_id not in game["players"]:
        return -2

    game["players"][player_id]["done"] = value

    state = await get_chat_state(chat_id)

    await state.update_data(
        {
            "blackjack": game
        }
    )


async def remove_game(chat_id):
    game = await get_game(chat_id)
    if game == -1:
        return -1

    state = await get_chat_state(chat_id)

    async with state.proxy() as data:
        del data["blackjack"]

    return True


def ifgame(runned: bool):
    def deco(func):
        @wraps(func)
        
        async def wrapper(message, **kw):
            
            if hasattr(message, "message"):
                query = message
                message = query.message
                message.from_user = query.from_user
                await query.answer()
            
            game = await get_game(message.chat.id)
            if game == -1:
                return
            if game["started"] == runned:
                return await func(message, **kw)
        return wrapper

    return deco


def get_cards_prize(
        cards: list
):
    sum = 0
    ace = []
    for card in cards:
        card = card[:-2]
        if strings.to_int(card) == "nan" or card == "K":
            if card != "A":
                sum += 10
            else:
                ace.append(card)
        else:
            sum += int(card)
    for card in ace:
        if sum > 10:
            sum += 1
        else:
            sum += 11
    return sum


id_message = {}


@ifgame(runned=False)
async def rates_double(
    message: types.Message
):
    chat_id = message.chat.id
    game = await get_game(chat_id)
    user_id = message.from_user.id
    if user_id not in game["players"]:
        return await message.bot.send_message(chat_id, f"{message.from_user.get_mention(as_html=True)}, У тебя нету ставок", parse_mode="HTML")
    rate_players = game["players"][user_id]["rate"]
    rate = rate_players*2
    balance = database_managment.get_balance(user_id)
    if rate_players > balance:
        return await message.bot.send_message(chat_id, f"{message.from_user.get_mention(as_html=True)}, недостаточно монет!", parse_mode="HTML")
    balance -= rate_players
    result = await double_rate(chat_id, user_id, rate)
    database_managment.switch_balance(user_id, balance)
    await message.bot.send_message(chat_id, f"{message.from_user.get_mention(as_html=True)}, ставка {strings.beautify_number(rate)} принята",
                                   parse_mode="HTML")

async def new_blackjack(
        message: types.Message
):
    bet = 0
    if hasattr(message, "message"):
        bet = 10
        query = message
        message = query.message
        message.from_user = query.from_user
        await query.answer()
    chat_id = message.chat.id
    result = await new_game(chat_id)
    if result != -1 and message.text.split()[0].lower() != "ставка":
        msg = await message.reply(
            "блэкджек запущен!\n\nСделать ставку: Блекджек 100\nРаздать карты: Раздать\nВзять карту: Ещё\nПосмотреть результат: Хватит", reply_markup = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Блэкджек 10", 
                callback_data = "new_blackjack"
            ),
            types.InlineKeyboardButton(
                "Удвоить", 
                callback_data = "rates_double"
            )
        ],
        [
            types.InlineKeyboardButton(
                "Отменить", 
                callback_data = "remove_the_player"
            ),
            types.InlineKeyboardButton(
                "Раздать", 
                callback_data = "start_blackjack"
            )
        ]
    ]
))
        id_message[chat_id] = msg.message_id
        await bot_pick_card(chat_id)
            
    game = await get_game(chat_id)
    
    if game["started"] is True:
        return await message.reply("В чате существует игра!")
        
    user_id = message.from_user.id
        
    if len(game["players"]) == 5 and await get_player_done(chat_id, user_id) == -2:
        return await message.reply(f"{message.from_user.get_mention(as_html=True)}, извините, мест нет!", parse_mode="HTML") 
    if bet != 10:
        if len(message.text.split()) > 1:
            bet = strings.to_int(message.text.split(maxsplit=1)[1].replace(" ", ""))

        if bet == "nan" or bet < 0:
            await message.bot.send_message(chat_id, f"{message.from_user.get_mention(as_html=True)}, ведите ставку правильно!", parse_mode="HTML")
            return await timer_for_rates(message)
    bet = round(bet)
    balance = database_managment.get_balance(user_id)

    if bet > balance:
        await message.bot.send_message(chat_id, f"{message.from_user.get_mention(as_html=True)}, у вас недостаточно монет!", parse_mode="HTML")
        return await timer_for_rates(message)
    name = message.from_user.get_mention(as_html=True)
    result_player = await new_player(chat_id, user_id, bet, name)

    if game == -1:
        return await message.bot.send_message(chat_id, f"{message.from_user.get_mention(as_html=True)}, игра не запущена!", parse_mode="HTML")

    look_result = database_managment.switch_balance(user_id, balance-bet)

    if look_result is not True:
        await message.bot.send_message(chat_id, f"{message.from_user.get_mention(as_html=True)}, что-то пошло не так!", parse_mode="HTML")
        return await timer_for_rates(message)
    
    await message.bot.send_message(chat_id, f"{message.from_user.get_mention(as_html=True)}, ставка {strings.beautify_number(result_player)} принята",
                                   parse_mode="HTML")
    return await timer_for_rates(message)


async def text_generator(message):
    chat_id = message.chat.id
    game = await get_game(chat_id)

    if not isinstance(game, dict): return
    text = f"Luke {game['bot'][0]} *"
    
    for player in game["players"]:
        cards = get_cards_prize(game["players"][player]['cards'])
        card_sum = f"({cards})"
        if cards > 21 or game["players"][player]["done"] is True:
            card_sum = f"({cards})👌"
            await set_player_done(chat_id, player, True)
        text += f"\n\n{game['players'][player]['name']} {''.join(game['players'][player]['cards'])} {card_sum}"
    await check_all_done(message)
    return text

@ifgame(runned=False)
async def start_blackjack(
        message: types.Message
):
    chat_id = message.chat.id
    
    if not hasattr(message, "auto"):
        user_id = message.from_user.id
    
        if await get_player_done(chat_id, user_id) == -2:
            return await message.bot.send_message(chat_id, f"{message.from_user.get_mention(as_html=True)}, ты не делал ставку!", parse_mode="HTML")
    if chat_id in start_timer:
        if start_timer[chat_id] < 30:
            return await message.bot.send_message(chat_id, f"{message.from_user.get_mention(as_html=True)}, подожди ещё {strings.beautify_date(timedelta(seconds=30-start_timer[chat_id]))}", parse_mode="HTML")
    try:
        await message.bot.delete_message(chat_id, id_message.pop(chat_id))
    except exceptions.MessageToDeleteNotFound:
        pass
    
    result = await start_game(chat_id)
    
    if chat_id in start_timer:
        start_timer.pop(chat_id)
    
    if result == -1:
        return
    if not hasattr(message, "auto"):
        await message.bot.send_message(chat_id, f"{message.from_user.get_mention(as_html=True)}, запустил игру!", parse_mode="HTML")   
    text = await text_generator(message)
    game = await get_game(chat_id)
    if game != -1:
        msg = await message.bot.send_message(chat_id, text, reply_markup = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Ещё", 
                callback_data = "pick_card_player"
            ),
            types.InlineKeyboardButton(
                "Хватит", 
                callback_data = "player_done"
            )
        ]
    ]
),  parse_mode="HTML")
        id_message[chat_id] = msg.message_id
        await timer_for_game(message)
    
@ifgame(runned=True)
async def pick_card_player(
    message: types.Message
):
    chat_id = message.chat.id
    user_id = message.from_user.id
    
    result = await get_player_done(chat_id, user_id) 
    
    if result == -2:
        return
        
    if result is True:
        return
        
    await pick_card(chat_id, user_id)
    
    text = await text_generator(message)
    if text:
        if chat_id in id_message:
            try:
                await message.bot.edit_message_text(text, chat_id, id_message[chat_id], reply_markup = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Ещё", 
                callback_data = "pick_card_player"
            ),
            types.InlineKeyboardButton(
                "Хватит", 
                callback_data = "player_done"
            )
        ]
    ]
), parse_mode="HTML")

            except exceptions.MessageToEditNotFound:
                pass
        
  
    
@ifgame(runned=True)  
async def player_done(
    message: types.Message
):
    chat_id = message.chat.id
    user_id = message.from_user.id
    
    result = await get_player_done(chat_id, user_id) 
    
    if result == -2:
        return
        
    if result is True:
        return
        
    await set_player_done(chat_id, user_id, True)
    
    await check_all_done(message)
    
    text = await text_generator(message)
    if text:
        if chat_id in id_message:
            try:
                await message.bot.edit_message_text(text, chat_id, id_message[chat_id], reply_markup = types.InlineKeyboardMarkup(
    inline_keyboard=[
        [
            types.InlineKeyboardButton(
                "Ещё", 
                callback_data = "pick_card_player"
            ),
            types.InlineKeyboardButton(
                "Хватит", 
                callback_data = "player_done"
            )
        ]
    ]
), parse_mode="HTML")

            except exceptions.MessageToEditNotFound:
                pass

async def check_all_done(
    message: types.Message
):
    chat_id = message.chat.id
    game = await get_game(chat_id)
    
    if game == -1:
        return -1
        
    for player in game["players"]:
        if not game["players"][player]["done"]:
            return True
            
    await the_end_game(message)

async def the_end_game(
        message: types.Message
):
    chat_id = message.chat.id
    if chat_id in id_message:
        try:
            await message.bot.delete_message(chat_id, id_message.pop(chat_id))
        except exceptions.MessageToDeleteNotFound:
            pass
    text = "Результат:"

    while True:

        cards = await bot_pick_card(chat_id)
        sum_bot = get_cards_prize(cards)

        if sum_bot >= 16:
            text += f"\nБот {''.join(cards)} ({sum_bot})"
            break
    game = await get_game(chat_id)
    await remove_game(chat_id)
    for player in game["players"]:

        chatmember: types.ChatMember = await message.chat.get_member(player)
        win = 0

        cards = game["players"][player]["cards"]
        sum = get_cards_prize(cards)
        rate = game["players"][player]["rate"]

        if sum == 21:
            win = round(rate*2.5)
            text += f"\n\n{chatmember.user.get_mention(as_html=True)} {''.join(game['players'][player]['cards'])} ({sum}) +{strings.beautify_number(win)}"
        elif sum_bot > 21 and sum <= 21:
            win = rate * 2
            text += f"\n\n{chatmember.user.get_mention(as_html=True)} {''.join(game['players'][player]['cards'])} ({sum}) +{strings.beautify_number(win)}"

        elif sum > sum_bot and sum <= 21:
            win = rate * 2
            text += f"\n\n{chatmember.user.get_mention(as_html=True)} {''.join(game['players'][player]['cards'])} ({sum}) +{strings.beautify_number(win)}"

        elif sum < sum_bot or sum > 21:
            text += f"\n\n{chatmember.user.get_mention(as_html=True)} {''.join(game['players'][player]['cards'])} ({sum}) проиграл"

        elif sum == sum_bot:
            win = rate
            text += f"\n\n{chatmember.user.get_mention(as_html=True)} {''.join(game['players'][player]['cards'])} ({sum}) ничья"

        rating = database_managment.get_rating(player)
        if win:
            database_managment.switch_rating(player, round(float(rating+0.3), 1))

        else:
            rating -= 0.1
            database_managment.switch_rating(player, round(float(rating), 1))

        database_managment.switch_balance(
                player,
                database_managment.get_balance(player) + win)

    await message.bot.send_message(chat_id, f"{text}\n\n{''.join(game['deck'])}", parse_mode="HTML")

    
@ifgame(runned=False)
async def remove_the_player(message):
    chat_id = message.chat.id
    game = await get_game(chat_id)
    user_id = message.from_user.id
    if user_id not in game["players"]:
        return await message.bot.send_message(chat_id, f"{message.from_user.get_mention(as_html=True)}, вы не делали ставку!", parse_mode="HTML")
    balance = database_managment.get_balance(user_id) + game["players"][user_id]["rate"]
    database_managment.switch_balance(user_id, balance)
    await remove_player(chat_id, user_id)
    await message.bot.send_message(chat_id, f"{message.from_user.get_mention(as_html=True)}, ваши ставки отменены!", parse_mode="HTML")
    
start_timer = {}
    
async def timer_for_rates(
    message: types.Message
):
    chat_id = message.chat.id
    if chat_id in start_timer:
        return
    start_timer[chat_id] = 0
    while True:
        start_timer[chat_id] += 1
        await sleep(1)
        game = await get_game(chat_id)
        if game["started"] is True:
            break
        if start_timer[chat_id] == 300:
            start_timer.pop(chat_id)
            message.auto = True
            await start_blackjack(message)
            break

async def timer_for_game(
    message: types.Message
):
    chat_id = message.chat.id
    game_timer = 0
    while True:
        game_timer += 1
        await sleep(1)
        game = await get_game(chat_id)
        if game == -1:
            break
        if game_timer == 300:
            message.auto = True
            await the_end_game(message)
            break     