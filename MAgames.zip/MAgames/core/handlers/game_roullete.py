import random
from typing import Union

from ..utils import strings, database_managment
import sqlite3
from asyncio import sleep
from aiogram import types
from aiogram import exceptions

rates_translate = {
    "к": "red",
    "красный": "red",
    "ч": "black",
    "черный": "black",
    "чёрный": "black",
}

roulette_log = {}


# получение результата
def get_result():
    value = random.randint(0, 18)

    if value == 0:
        return ["💰0", f"{value}", value]

    if value > 10:
        if value % 2 == 0:
            return [f"🔴{value}", "red", value]
        else:
            return [f"⚫️{value}", "black", value]
    else:
        if value % 2 == 0:
            return [f"⚫️{value}", "black", value]
        else:
            return [f"🔴{value}", "red", value]


already_work = {}
game = {}
roulette_durations = {}


async def timer(message, bot):
    global game
    global roulette_durations
    chat_id = message.chat.id
    roulette_durations[chat_id] = 0
    while True:
        global game
        if chat_id in game:
            await sleep(1)
            roulette_durations[chat_id] += 1
            if roulette_durations[chat_id] >= 300:
                if chat_id not in blocked_chats:
                    blocked_chats.append(chat_id)
                await take_result(message, bot)
                if chat_id in already_work:
                    try:
                        await bot.delete_message(chat_id, already_work.pop(chat_id))
                    except exceptions.MessageToDeleteNotFound:
                        pass
                break

        else:
            try:
                await bot.delete_message(chat_id, already_work[chat_id])
            except exceptions.MessageToDeleteNotFound:
                pass
            already_work.pop(chat_id)
            break


blocked_chats = []


async def take_result(message: types.Message, bot):
    global game

    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()

    chat_id = message.chat.id

    if chat_id not in blocked_chats:
        return

    blocked_chats.remove(chat_id)

    game_result = get_result()

    status_message = await bot.send_animation(
        chat_id, types.InputFile(f"core/gift/{random.randint(1, 3)}.mp4")
    )

    await sleep(5)

    await status_message.delete()

    text_rates = f"Выпало: {game_result[0]}\nСтавки:\n"
    text_win = "\nВыплаты:\n"

    for user_id in game[chat_id]:
        user_gain = 0
        member: types.ChatMember = await message.chat.get_member(user_id)
        for rate, bet in game[chat_id][user_id].items():
            integer_rate = strings.to_int(rate)

            rate_translate = {"black": "чёрный", "red": "Красный"}

            beauty_rate = rate if integer_rate != "nan" else rate_translate[rate]

            if rate == game_result[2]:
                user_gain += bet * 18
            elif rate == game_result[1]:
                user_gain += bet * 2

            text_rates += (
                f"{member.user.get_mention(as_html=True)} "
                f"{strings.beautify_number(bet)} на {beauty_rate}\n"
            )

        rating = database_managment.get_rating(user_id)
        if user_gain > 0:
            text_win += f"{member.user.get_mention(as_html=True)} {strings.beautify_number(user_gain)} монет\n"
            cursor.execute("SELECT balance FROM players WHERE id = ?", (user_id,))
            database_managment.switch_balance(
                user_id, int(cursor.fetchone()[0]) + user_gain
            )
            connection.commit()
            database_managment.switch_rating(user_id, round(float(rating + 0.3), 1))

        else:
            rating -= 0.1
            database_managment.switch_rating(user_id, round(float(rating), 1))

    text_rates += text_win

    game.pop(chat_id)

    if chat_id not in roulette_log:
        roulette_log[chat_id] = [game_result[0]]

    elif len(roulette_log[chat_id]) >= 10:
        roulette_log[chat_id].pop(0)
        roulette_log[chat_id].append(game_result[0])

    else:
        roulette_log[chat_id].append(game_result[0])

    await bot.send_message(chat_id, text_rates, parse_mode="HTML")


async def show_log(message: Union[types.Message, types.CallbackQuery]):
    if hasattr(message, "message"):
        query = message
        message = query.message
        message.from_user = query.from_user
        await query.answer()

    chat_id = message.chat.id

    if chat_id not in roulette_log:
        roulette_log[chat_id] = []

    if not len(roulette_log[chat_id]):
        return await message.bot.send_message(
            chat_id,
            f"{message.from_user.get_mention(as_html=True)}, тут пока ничего нет",
            parse_mode="HTML",
        )

    text = "лог:\n" + "\n".join(roulette_log[chat_id])

    await message.bot.send_message(
        chat_id,
        f"{message.from_user.get_mention(as_html=True)}, {text}",
        parse_mode="HTML",
    )


async def show_rates(message: Union[types.Message, types.CallbackQuery]):
    global game
    if hasattr(message, "message"):
        query = message
        message = query.message
        message.from_user = query.from_user
        await query.answer()

    chat_id = message.chat.id
    user_id = message.from_user.id

    if chat_id not in game:
        return await message.bot.send_message(
            chat_id,
            f"{message.from_user.get_mention(as_html=True)}, рулетка не запущена!",
            parse_mode="HTML",
        )

    if user_id not in game[chat_id]:
        return await message.bot.send_message(
            chat_id,
            f"{message.from_user.get_mention(as_html=True)}, вы не делали ставки!",
            parse_mode="HTML",
        )

    text = "ставки:\n"
    for rates in game[chat_id][user_id]:

        integer_rate = strings.to_int(rates)

        if integer_rate == "nan":
            if rates == "red":
                beauty_rate = "Красный"
            else:
                beauty_rate = "Чёрный"
        else:
            beauty_rate = rates
        text += (
            f"{beauty_rate} {strings.beautify_number(game[chat_id][user_id][rates])}\n"
        )

    await message.bot.send_message(
        chat_id,
        f"{message.from_user.get_mention(as_html=True)}, ваши {text}",
        parse_mode="HTML",
    )


async def double_rates(message: Union[types.Message, types.CallbackQuery]):
    if hasattr(message, "message"):
        query = message
        message = query.message
        message.from_user = query.from_user
        await query.answer()

    chat_id = message.chat.id
    user_id = message.from_user.id

    if chat_id not in game:
        return await message.bot.send_message(
            chat_id,
            f"{message.from_user.get_mention(as_html=True)}, рулетка не запущена!",
            parse_mode="HTML",
        )

    if user_id not in game[chat_id]:
        return await message.bot.send_message(
            chat_id,
            f"{message.from_user.get_mention(as_html=True)}, вы не делали ставки!",
            parse_mode="HTML",
        )

    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()
    cursor.execute("SELECT balance FROM players WHERE id = ?", (user_id,))
    balance = int(cursor.fetchone()[0])

    total_sum = sum(game[chat_id][user_id].values())

    if balance < total_sum:
        return await message.bot.send_message(
            chat_id,
            f"{message.from_user.get_mention(as_html=True)}, у вас недостаточно монет!",
            parse_mode="HTML",
        )

    for rate in game[chat_id][user_id].keys():
        game[chat_id][user_id][rate] *= 2

    cursor.execute(
        "UPDATE players SET balance=? WHERE id = ?", (balance - total_sum, user_id)
    )
    connection.commit()
    await message.bot.send_message(
        chat_id,
        f"{message.from_user.get_mention(as_html=True)}, ставки были удвоены!",
        parse_mode="HTML",
    )


async def delete_rates(message):
    global game
    if hasattr(message, "message"):
        query = message
        message = query.message
        message.from_user = query.from_user
        await query.answer()

    chat_id = message.chat.id
    user_id = message.from_user.id

    if chat_id not in game:
        return await message.bot.send_message(
            chat_id,
            f"{message.from_user.get_mention(as_html=True)}, рулетка не запущена!",
            parse_mode="HTML",
        )

    if user_id not in game[chat_id]:
        return await message.bot.send_message(
            chat_id,
            f"{message.from_user.get_mention(as_html=True)}, вы не делали ставки!",
            parse_mode="HTML",
        )

    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()

    total_sum = sum(game[chat_id][user_id].values())

    cursor.execute(
        "SELECT " "balance " "FROM " "players " "WHERE " "id = ?", (user_id,)
    )

    database_managment.switch_balance(user_id, int(cursor.fetchone()[0]) + total_sum)

    game[chat_id].pop(user_id)

    await message.bot.send_message(
        chat_id,
        f"{message.from_user.get_mention(as_html=True)}, ставки успешно отменены!",
        parse_mode="HTML",
    )


async def start_roulette(message):
    chat_id = message.chat.id
    if chat_id in already_work:
        return await message.reply("Рулетка уже запущена!")

    message_roulette = await message.answer(
        f'Запуск командой "Го", ставки:\n'
        f'| к 100 | ч 100 | 0 100 |\n'
        f'Так же на любое число от 1 до 18\n'
        f'!от - Отмена, !с - Ставки, !у - Удалить\n'
        f'0💰|🔴1|⚫️2️|🔴3\n'
        f'⚫️4|🔴5|⚫️6|🔴7\n'
        f'⚫️8|🔴9|⚫️10|⚫️11\n'
        f'🔴12|⚫️13|🔴14|⚫️15\n'
        f'🔴16|⚫️17|🔴18\n'
        f'Лог',
        reply_markup=types.InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    types.InlineKeyboardButton(
                        "Отменить", callback_data="delete_rates"
                    ),
                    types.InlineKeyboardButton("Ставки", callback_data="show_rates"),
                ],
                [
                    types.InlineKeyboardButton("Удвоить", callback_data="double_rates"),
                    types.InlineKeyboardButton("Лог", callback_data="show_log"),
                ],
            ]
        ),
    )

    game[chat_id] = {}

    already_work[chat_id] = message_roulette.message_id

    await timer(message, message.bot)


def new_rate(chat_id: int, user_id: int, type: str, size: int):
    if chat_id not in game:
        game[chat_id] = {}
    if user_id not in game[chat_id]:
        game[chat_id][user_id] = {}

    if type in game[chat_id][user_id]:
        game[chat_id][user_id][type] += size
        return True

    game[chat_id][user_id][type] = size
    return True


async def add(message):
    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()
    chat_id = message.chat.id

    if chat_id not in game:
        return

    user_id = message.from_user.id

    if len(message.text.split()) < 2:
        return await message.reply("Ты забыл указать сумму ставки")

    cursor.execute(
        "SELECT balance FROM players WHERE id = ?", (user_id,)
    )

    balance = int(cursor.fetchone()[0])

    allowed_rate_types = list(map(str, range(19))) + list(rates_translate)

    text = ""
    for rate in message.text.splitlines():

        rate_type = rate.split()[0].lower()
        if rate_type not in allowed_rate_types:
            text += "Что-то тут не так..\n"
            continue

        bet = strings.to_int(rate.split(maxsplit=1)[1].replace(" ", ""))

        if bet == "nan" or bet < 0:
            text += "Укажите ставку в нормальном формате!\n"
            continue

        bet = round(bet)
        if balance < bet:
            text += "У вас не хватает монет!\n"
            continue

        if rate_type in rates_translate:
            rate_type = rates_translate[rate_type]
        if strings.to_int(rate_type) != "nan" and rate_type != "к":
            rate_type = int(rate_type)

        new_rate(chat_id, user_id, rate_type, bet)

        balance -= bet

        rate_name = rate_type
        if rate_type == "red":
            rate_name = "красный"
        elif rate_type == "black":
            rate_name = "чёрный"

        text += f"{strings.beautify_number(bet)} монет на {rate_name}\n"

    cursor.execute(
        "UPDATE players SET balance=?WHERE id=?", (balance, user_id)
    )
    connection.commit()
    await message.reply(text, parse_mode="HTML")


async def start_result_roulette(message):
    global game
    global roulette_durations

    chat_id = message.chat.id
    if chat_id not in game:
        return await message.reply("Рулетка не запущена!")

    user_id = message.from_user.id
    if user_id not in game[chat_id]:
        return await message.reply("Ты не в игре!")

    if chat_id in roulette_durations:
        if roulette_durations[chat_id] < 60:
            return await message.reply(
                f"Еще рано, жди {60 - roulette_durations[chat_id]} секунд"
            )
    else:
        return
    blocked_chats.append(chat_id)
    await take_result(message, message.bot)
