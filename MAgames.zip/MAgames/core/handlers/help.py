from aiogram import types

keyboardhelp = types.InlineKeyboardMarkup()
keyboardhelp.add(types.InlineKeyboardButton(text='полный гайд⁉️', url='https://telegra.ph/GAJD-PO-BOTU-10-24-2'))

async def help_luke(
    message: types.Message
):
    chat_id = message.chat.id
    await message.reply('Прошу прочитать весь гайд по боту\nКанал бота: @MAGamesNEWS\nОфициальный чат бота: @MAGamesCHAT', reply_markup=keyboardhelp)