from aiogram import types

async def getId(message: types.Message):
    if not message.reply_to_message:
        id = message.from_user.id
        await message.answer(f'Твой ID: <code>{id}</code>', parse_mode='HTML')
    else:
        id = message.reply_to_message.from_user.id
        if id == message.from_user.id:
            await message.answer(f'Твой ID: <code>{message.from_user.id}</code>', parse_mode='HTML')
        else:
            await message.answer(f'ID\n<code>{id}</code>', parse_mode='HTML')