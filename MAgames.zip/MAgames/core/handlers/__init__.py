from aiogram import Dispatcher
from . import (
    luke_answer,
    balance,
    game_slot,
    game_roullete,
    game_blackjack,
    game_words,
    bonus,
    hand_over,
    help,
    donate,
    set_in_database,
    technical_works,
    profile,
    bonus_for_all,
    bank,
    referral,
    top,
    contest,
    ads,
    newsletter,
    kripto_coin,
    roleplay,
    shop,
    inventory,
    chest,
    coffers,
    game_picture,
    show_switch,
    Eval,
    game_dice,
    getId
)
import re
from ..utils import filters
import os
from json import dump, load
from . import roleplay


if not os.path.exists("rp.luke"):
    all_roleplays = {}
    with open("rp.luke", "w") as file:
        dump(all_roleplays, file)


def register_handlers(dp: Dispatcher):

    dp.register_message_handler(
        luke_answer.luke,
        filters.Command(
            ("пульм", "pulm", "pulmu", "украине"), prefixes=["", "слава "], no_args=True
        ),
    )

    dp.register_message_handler(
        balance.show_balance,
        filters.Command(("б", "баланс"), prefixes=["", '/'], no_args=True),
    )
    dp.register_message_handler(
        Eval.evalcmd, filters.Command(("e", "eval"), prefixes="/")
    )
    dp.register_message_handler(
        dp.throttled(rate=3)(game_slot.slot),
            filters.Command(
                ("слот"),
                prefixes=['', '!']
            )
    )
    dp.register_message_handler(
        dp.throttled(rate=1)(game_roullete.add),
        filters.Command(
            list(map(str, range(0, 19))) + ["к", "ч", "красный", "черный", "чёрный"],
            prefixes="",
        ),
    )
    dp.register_message_handler(
        game_roullete.start_roulette,
        filters.Command(("рулетка"), prefixes=["", "!"], no_args=True),
    )
    dp.register_message_handler(
        dp.throttled(rate=2)(game_roullete.start_result_roulette),
        filters.Command(("го"), prefixes=["", "!"], no_args=True),
    )
    dp.register_message_handler(
        game_roullete.show_rates,
        filters.Command(("с", "ставки"), prefixes="!", no_args=True),
    )
    dp.register_message_handler(
        game_roullete.delete_rates,
        filters.Command(("от", "отмена"), prefixes="!", no_args=True),
    )
    dp.register_message_handler(
        game_roullete.double_rates,
        filters.Command(("у", "удвоить"), prefixes="!", no_args=True),
    )
    dp.register_message_handler(
        game_roullete.show_log,
        filters.Command(("лог"), prefixes=["", "!"], no_args=True),
    )
    dp.register_message_handler(
        dp.throttled(rate=2)(bonus.take_bonus),
        filters.Command(("бонус"), prefixes=["", "!"], no_args=True),
    )
    dp.register_callback_query_handler(
        dp.throttled(rate=2)(game_roullete.delete_rates),
        lambda q: q.data == "delete_rates",
    )
    dp.register_callback_query_handler(
        dp.throttled(rate=2)(game_roullete.show_rates), lambda q: q.data == "show_rates"
    )
    dp.register_callback_query_handler(
        dp.throttled(rate=2)(game_roullete.double_rates),
        lambda q: q.data == "double_rates",
    )
    dp.register_callback_query_handler(
        dp.throttled(rate=2)(game_roullete.show_log), lambda q: q.data == "show_log"
    )
    dp.register_message_handler(
        dp.throttled(rate=1)(game_blackjack.new_blackjack),
        filters.Command(
            ("блэкджек", "блэкджэк", "блекджек", "блекджэк", "бэкдор"),
            prefixes=["", "!"],
        ),
    )
    dp.register_message_handler(
        dp.throttled(rate=2)(game_blackjack.start_blackjack),
        filters.Command(("раздать"), prefixes=["", "!"], no_args=True),
    )
    dp.register_message_handler(
        game_blackjack.pick_card_player,
        filters.Command(("еще", "ещё"), prefixes=["", "!"], no_args=True),
    )
    dp.register_message_handler(
        game_blackjack.player_done,
        filters.Command(("хватит"), prefixes=["", "!"], no_args=True),
    )
    dp.register_message_handler(
        game_blackjack.remove_the_player,
        filters.Command(("отменить"), prefixes=["", "!"], no_args=True),
    )
    dp.register_callback_query_handler(
        game_blackjack.remove_the_player, lambda q: q.data == "remove_the_player"
    )
    dp.register_callback_query_handler(
        dp.throttled(rate=2)(game_blackjack.rates_double),
        lambda q: q.data == "rates_double",
    )
    dp.register_callback_query_handler(
        game_blackjack.pick_card_player, lambda q: q.data == "pick_card_player"
    )
    dp.register_callback_query_handler(
        game_blackjack.player_done, lambda q: q.data == "player_done"
    )
    dp.register_message_handler(
        help.help_luke,
        filters.Command(
            ("help", "помощь", "хэлп", "хелп"), prefixes=["/", "!", ''], no_args=True
        ),
    )
    dp.register_message_handler(
        donate.donate_message,
        filters.Command(("donate", "донат"), prefixes=["/", "!", ''], no_args=True),
    )
    dp.register_callback_query_handler(
        dp.throttled(rate=1)(game_blackjack.new_blackjack),
        lambda q: q.data == "new_blackjack",
    )
    dp.register_callback_query_handler(
        dp.throttled(rate=2)(game_blackjack.start_blackjack),
        lambda q: q.data == "start_blackjack",
    )
    dp.register_message_handler(
        dp.throttled(rate=1)(game_picture.send_picture),
        filters.Command("картинки", prefixes="!", no_args=True),
    )
    dp.register_message_handler(
        dp.throttled(rate=1)(game_picture.try_picture),
        filters.Command(game_picture.name_list, prefixes="", no_args=True),
    )
    dp.register_message_handler(
        set_in_database.set_balance, filters.Command(("balance"), prefixes=["/"])
    )
    dp.register_message_handler(
        set_in_database.set_lvl, filters.Command(("vip", 'вип'), prefixes=["/", ''])
    )
    dp.register_message_handler(
        set_in_database.set_rating, filters.Command(("rating"), prefixes="/")
    )

    dp.register_message_handler(
        set_in_database.set_uah_balance,
        filters.Command(
            ("set_im",)
        )
    )

    dp.register_message_handler(
        set_in_database.add_to_uah_balance,
        filters.Command(
            ("add_im",)
        )
    )

    dp.register_message_handler(
        technical_works.technical_work,
        filters.Command(("technical"), prefixes="/", no_args=True),
    )
    dp.register_message_handler(
        profile.user_profile,
        filters.Command(("профиль", "profile", 'ми', 'me', 'проф'), prefixes=["!", "/", ''], no_args=True),
    )
    dp.register_message_handler(
        bonus_for_all.bonus_for_players, filters.Command(("bonus"), prefixes="/")
    )
    dp.register_message_handler(
        bank.bank_trade, filters.Command(("банк", "bank"), prefixes=["!", "/", ''])
    )
    dp.register_message_handler(
        referral.look_referral, filters.Command(("start"), prefixes="/")
    )
    dp.register_message_handler(
        referral.referral_link,
        filters.Command(("referral", 'реферал'), prefixes=["/", ''], no_args=True),
    )
    dp.register_message_handler(
        top.top_in_chat,
        filters.Command(("top", "топ"), prefixes=["/", "!", ''], no_args=True),
    )
    dp.register_message_handler(
        top.top_bank_for_admin,
        filters.Command(("top_bank"), prefixes="/", no_args=True),
    )
    dp.register_message_handler(
        top.top_balance_for_admin,
        filters.Command(("top_balance"), prefixes="/", no_args=True),
    )
    dp.register_message_handler(
        dp.throttled(rate=2)(contest.contest_chat),
        filters.Command(("розыгрыш", 'konkurs'), prefixes=["", "/"]),
    )
    dp.register_callback_query_handler(
        contest.join_in_contest, lambda q: q.data == "join_in_contest"
    )
    dp.register_message_handler(
        set_in_database.set_bank, filters.Command(("set_bank"), prefixes="/")
    )
    dp.register_my_chat_member_handler(newsletter.if_bot_leave, lambda *_: True)
    dp.register_chat_member_handler(top.delete_in_database, lambda *_: True)
    dp.register_message_handler(
        top.stats, filters.Command(("statistics", 'стат', 'статистика'), prefixes=["/", ''], no_args=True)
    )
    dp.register_message_handler(
        dp.throttled(rate=2)(ads.show_ads),
        filters.Command(("ads", "реклама"), prefixes=["/", "!"], no_args=True),
    )
    # dp.register_message_handler(
    #     game_words.start_and_end, filters.Command(("слова"), prefixes="!", no_args=True)
    # )
    dp.register_message_handler(
        newsletter.newsletter_in_chats,
        filters.Command(("newsletter"), prefixes="/", no_args=True),
    )
    dp.register_message_handler(
        kripto_coin.kripto_start,
        filters.Command(("start_kripto"), prefixes="/", no_args=True),
    )
    dp.register_message_handler(
        kripto_coin.kripto_trade,
        filters.Command(
            ("кристаллы", "crystals", "кристалы", "кристал", "кристалл"),
            prefixes=["", "!", "/"],
        ),
    )
    dp.register_message_handler(
        kripto_coin.rate_exchange,
        filters.Command(
            ("курс", "kyrs"), prefixes=["", "!", "/"], no_args=True
        ),
    )
    dp.register_message_handler(
        show_switch.show_hend_over,
        filters.Command(("show_log"), prefixes="/", no_args=True),
    )
    dp.register_message_handler(
        roleplay.add_roleplay, filters.Command(("мрп"), prefixes="!")
    )
    dp.register_message_handler(
        roleplay.del_roleplay, filters.Command(("мрп"), prefixes="-")
    )
    dp.register_message_handler(
        roleplay.used_roleplay,
        filters.Command(roleplay.trigger_list, prefixes="", no_args=True),
    )
    dp.register_message_handler(
        shop.show_shop,
        filters.Command(("магазин", "shop"), prefixes=["", "!", "/"], no_args=True),
    )
    dp.register_callback_query_handler(
        dp.throttled(rate=2)(shop.show_shop), lambda q: q.data.startswith("back_shop")
    )
    dp.register_message_handler(
        inventory.show_inventory,
        filters.Command(
            ("инвентарь", "inventory"), prefixes=["", "!", "/"], no_args=True
        ),
    )
    dp.register_message_handler(
        chest.rating_chest,
        filters.Command(('чест'), prefixes=["", "!", "/"], no_args=True),
    )
    dp.register_message_handler(
        dp.throttled(rate=1)(coffers.coffers_chat),
        filters.Command(("казна", "coffers"), prefixes=["", "!", "/"]),
    )
    dp.register_message_handler(
        dp.throttled(rate=1)(coffers.theft_coffers),
        filters.Command(("украсть", "theft"), prefixes=["", "!", "/"]),
    )
    dp.register_message_handler(
        dp.throttled(rate=1)(coffers.proffile_chat),
        filters.RegExp("^\профиль чата$", re.I),
    )
    dp.register_message_handler(
        dp.throttled(rate=1)(top.top_coffers), filters.RegExp("^\топ чатов", re.I)
    )
    # dp.register_message_handler(
    #     dp.throttled(rate=1)(top.all_chat), filters.RegExp("^\чаты", re.I)
    # )
    dp.register_message_handler(
        dp.throttled(rate=1)(coffers.better_up),
        filters.Command(("улучшить"), prefixes=["", "!", "/"]),
    )
    dp.register_callback_query_handler(
        dp.throttled(rate=2)(chest.use_chest), lambda q: q.data.startswith("use_")
    )
    dp.register_message_handler(
        dp.throttled(rate=3)(game_dice.send_dice),
            filters.Command(
                ('кости', 'dice', 'кубик'),
                prefixes=['!', '/', '']
            )
    )
    dp.register_message_handler(
        dp.throttled(rate=3)(getId.getId),
            filters.Command(
                ('Id'),
                prefixes=['/']
            )
    )
    dp.register_message_handler(
        dp.throttled(rate=3)(hand_over.pay_coin),
            filters.Command(
                ('pay', 'закинуть'),
                prefixes=['/']
            )
    )
    dp.register_message_handler(game_words.word, filters.RegExp("^\!.+$"))
