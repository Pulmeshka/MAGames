from aiogram import types
import os
from json import load

from ..config import admin


async def show_hend_over(
    message: types.Message
):
    user_id = message.from_user.id

    if user_id not in admin:
        return

    if not os.path.exists("transfer_coins.log"):
        return await message.reply('Логов нет!')

    with open('transfer_coins.log', 'r') as file:
        transfer_coins_log = load(file)

    text = ''

    text += "\n".join(
        f"+{transaction['sum']} {transaction['sender_mention']}[{transaction['sender_id']}] => "
        f"{transaction['receiver_mention']}[{transaction['receiver_id']}]"
        for transaction in transfer_coins_log
    )

    await message.reply(
        text,
        parse_mode='HTML'
    )
