import sqlite3

directory = "core/database/players.db"


def get_connection():
    return sqlite3.connect(directory)

def get_player(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()

    keys = (
        "id;balance;rights_level;"
        "is_blocked;bank;referral;"
        "invited;rating;marry;"
        "transfer_limit;uah_balance;kripto"
    )

    player_raw = cursor.execute(
        "SELECT "
        +
          ", ".join(keys.split(";"))
        +
        " FROM players WHERE id=?",
        (user_id, )
    ).fetchone()

    connection.close()

    return {
        key: value
        for key, value in zip(keys.split(";"), player_raw)
    }


def add_player_uah(user_id: int, number: float):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()

    cursor.execute(
        "UPDATE players SET uah_balance=uah_balance+? WHERE id=?",
        (number, user_id)
    )

    connection.commit()
    connection.close()


def set_player_uah(user_id: int, number: float):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()

    cursor.execute(
        "UPDATE players SET uah_balance=? WHERE id=?",
        (number, user_id)
    )

    connection.commit()
    connection.close()


def get_theft(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute("SELECT " "theft " "FROM " "players " "WHERE " "id=?", (user_id,))
    theft = cursor.fetchone()
    if theft is None:
        return None
    return theft[0]


def get_protection_chat(chat_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "SELECT " "protection " "FROM " "chats " "WHERE " "chat_id=?", (chat_id,)
    )
    protection = cursor.fetchone()
    if protection is None:
        return None
    return protection[0]

#bonus_all
def get_bronze(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute("SELECT " "bronze " "FROM " "inventory " "WHERE " "id=?", (user_id,))
    bronze = cursor.fetchone()
    if bronze is None:
        return None
    return bronze[0]


def get_chat_balance(chat_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "SELECT " "balance " "FROM " "chats " "WHERE " "chat_id=?", (chat_id,)
    )
    balance = cursor.fetchone()
    if balance is None:
        return None
    return balance[0]


def get_iron(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute("SELECT " "iron " "FROM " "inventory " "WHERE " "id=?", (user_id,))
    iron = cursor.fetchone()
    if iron is None:
        return None
    return iron[0]


def get_silver(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute("SELECT " "silver " "FROM " "inventory " "WHERE " "id=?", (user_id,))
    silver = cursor.fetchone()
    if silver is None:
        return None
    return silver[0]


def get_gold(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute("SELECT " "gold " "FROM " "inventory " "WHERE " "id=?", (user_id,))
    gold = cursor.fetchone()
    if gold is None:
        return None
    return gold[0]


def get_diamond(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "SELECT " "diamond " "FROM " "inventory " "WHERE " "id=?", (user_id,)
    )
    diamond = cursor.fetchone()
    if diamond is None:
        return None
    return diamond[0]


def get_balance(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute("SELECT " "balance " "FROM " "players " "WHERE " "id=?", (user_id,))
    balance = cursor.fetchone()
    if balance is None:
        return None

    return balance[0]


def get_limit(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "SELECT " "transfer_limit " "FROM " "players " "WHERE " "id=?", (user_id,)
    )
    result = cursor.fetchone()
    if result is None:
        return None

    return result[0]


def get_rating(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute("SELECT " "rating " "FROM " "players " "WHERE " "id=?", (user_id,))
    rating = cursor.fetchone()
    if rating is None:
        return None

    return rating[0]


def get_vip(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "SELECT " "rights_level " "FROM " "players " "WHERE " "id=?", (user_id,)
    )
    vip = cursor.fetchone()
    if vip is None:
        return None

    return vip[0]


def get_invited(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute("SELECT " "invited " "FROM " "players " "WHERE " "id=?", (user_id,))
    invited = cursor.fetchone()
    if invited is None:
        return None

    return invited[0]


def get_marry(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute("SELECT " "marry " "FROM " "players " "WHERE " "id=?", (user_id,))
    marry = cursor.fetchone()
    if marry is None:
        return None

    return marry[0]


def get_referral(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute("SELECT " "referral " "FROM " "players " "WHERE " "id=?", (user_id,))
    referral = cursor.fetchone()
    if referral is None:
        return None

    return referral[0]


def switch_balance(user_id, balance):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    limit = 9200000000000000000
    min = 100
    if balance > limit:
        bank = get_bank(user_id)
        old_balance = get_balance(user_id)
        sum = balance - old_balance
        balance = old_balance
        sum = bank + int(sum / min)
        trade_bank(user_id, sum)
    cursor.execute(
        "UPDATE " "players " "SET " "balance=?" "WHERE " "id=?", (balance, user_id)
    )
    connection.commit()
    return True


def switch_level(user_id, lvl):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "UPDATE " "players " "SET " "rights_level=?" "WHERE " "id=?", (lvl, user_id)
    )
    connection.commit()
    return True


def switch_referral(user_id, referral):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "UPDATE " "players " "SET " "referral=?" "WHERE " "id=?", (referral, user_id)
    )
    connection.commit()
    return True


def switch_chat_balance(chat_id, balance):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "UPDATE " "chats " "SET " "balance=?" "WHERE " "chat_id=?",
        (int(balance), chat_id),
    )
    connection.commit()
    return True


def switch_rating(user_id, rating):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    if rating < 0:
        rating = 0.0

    cursor.execute(
        "UPDATE " "players " "SET " "rating=?" "WHERE " "id=?", (rating, user_id)
    )
    connection.commit()
    return True


def switch_limit(user_id, limit):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "UPDATE "
        "players "
        "SET "
        f"transfer_limit=transfer_limit-{limit} "
        "WHERE "
        "id=?",
        (user_id,),
    )
    connection.commit()
    return True

def set_limit(user_id, limit):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "UPDATE "
        "players "
        "SET "
        "transfer_limit=?"
        "WHERE "
        "id=?",
        (limit, user_id),
    )
    connection.commit()
    return True


def update_limit():
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute("UPDATE " "players " "SET " "transfer_limit=5000")
    connection.commit()
    return True


def switch_theft(user_id, theft):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "UPDATE " "players " "SET " "theft=?" "WHERE " "id=?", (theft, user_id)
    )
    connection.commit()
    return True


def switch_chat_protection(chat_id, protection):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "UPDATE " "chats " "SET " "protection=?" "WHERE " "chat_id=?",
        (protection, chat_id),
    )
    connection.commit()
    return True


def switch_awards(user_id, awards):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "UPDATE " "players " "SET " "awards=?" "WHERE " "id=?", (awards, user_id)
    )
    connection.commit()
    return True


def switch_invited(user_id, invited):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "UPDATE " "players " "SET " "invited=?" "WHERE " "id=?", (invited, user_id)
    )
    connection.commit()
    return True


def switch_marry(user_id, marry):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "UPDATE " "players " "SET " "marry=?" "WHERE " "id=?", (marry, user_id)
    )
    connection.commit()
    return True


def get_bank(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute("SELECT " "bank " "FROM " "players " "WHERE " "id=?", (user_id,))
    return cursor.fetchone()[0]


def trade_bank(user_id, sum):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute("UPDATE " "players " "SET " "bank=?" "WHERE " "id=?", (sum, user_id))
    connection.commit()
    return True


def bonus_all(sum):
    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()
    cursor.execute("UPDATE " "players " "SET " "balance=balance+?", (sum,))
    connection.commit()

    return True


def top_chat(chat_id):
    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()
    cursor.execute(
        "SELECT "
        "players.id, "
        "players.balance "
        "FROM "
        "players, chats_and_participants "
        "WHERE "
        "players.id = chats_and_participants.user_id "
        "AND "
        "players.rights_level < 4 "
        "AND "
        "chats_and_participants.chat_id=? "
        "ORDER BY "
        "players.balance "
        "DESC LIMIT "
        "10",
        (chat_id,),
    )
    return cursor.fetchall()


def top_bank():
    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()

    cursor.execute(
        "SELECT "
        "players.id, "
        "players.bank "
        "FROM "
        "players "
        "ORDER BY "
        "players.bank "
        "DESC LIMIT "
        "10"
    )
    return cursor.fetchall()


def top_balance():
    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()

    cursor.execute(
        "SELECT "
        "players.id, "
        "players.balance "
        "FROM "
        "players "
        "ORDER BY "
        "players.balance "
        "DESC LIMIT "
        "10"
    )
    return cursor.fetchall()


def top_chat_balance():
    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()

    cursor.execute(
        "SELECT "
        "chats.chat_id, "
        "chats.balance "
        "FROM "
        "chats "
        "ORDER BY "
        "chats.balance "
        "DESC LIMIT "
        "10"
    )
    return cursor.fetchall()


def delete_in_chat(user_id, chat_id):
    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()
    cursor.execute(
        "DELETE FROM "
        "chats_and_participants "
        "WHERE "
        "user_id=? "
        "AND "
        "chat_id=?",
        (user_id, chat_id),
    )
    connection.commit()
    return True


def delete_chat(chat_id):
    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()
    cursor.execute("DELETE FROM " "chats " "WHERE " "chat_id=?", (chat_id,))
    connection.commit()
    return True


def show_all_players():
    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()
    cursor.execute("SELECT COUNT " "(" "id" ") " "FROM " "players")
    return cursor.fetchone()[0]


def show_sum_chat():
    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()
    cursor.execute(
        "SELECT " "chat_id " "FROM " "chats_and_participants " "GROUP BY " "chat_id"
    )
    return cursor.fetchall()


def delete_chats(chat_id):
    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()
    cursor.execute(
        "DELETE FROM " "chats_and_participants " "WHERE " "chat_id=?", (chat_id,)
    )
    connection.commit()
    return True


def get_kripto(user_id):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute("SELECT " "kripto " "FROM " "players " "WHERE " "id=?", (user_id,))
    kripto = cursor.fetchone()
    if kripto is None:
        return None

    return kripto[0]


def switch_kripto(user_id, kripto):
    connection = sqlite3.connect(directory)
    cursor = connection.cursor()
    cursor.execute(
        "UPDATE " "players " "SET " "kripto=?" "WHERE " "id=?", (kripto, user_id)
    )
    connection.commit()
    return True
