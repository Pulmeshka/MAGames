import re
from datetime import datetime, timedelta
from typing import Union

modifiers = {
    ("г", "g"): "000000000",
    ("м", "m"): "000000",
    ("к", "k"): "000",
}
mod = {key: value for key, value in modifiers.items() for key in key}

variants_uk = {
    "days": ("день", "дня", "дней"),
    "in_days": ("день", "дня", "дней"),
    "months": ("месяц", "месяца", "месяцев"),
    "in_months": ("месяц", "месяца", "месяцев"),
    "years": ("год", "года", "лет"),
    "in_years": ("год", "года", "лет"),
    "weeks": ("неделя", "недели", "недель"),
    "in_weeks": ("неделю", "недели", "недель"),
    "minutes": ("минута", "минуты", "минут"),
    "in_minutes": ("минуту", "минуты", "минут"),
    "seconds": ("секунда", "секунды", "секунд"),
    "in_seconds": ("секунду", "секунды", "секунд"),
    "hours": ("час", "часа", "часов"),
    "in_hours": ("час", "часа", "часов"),
    "coins": ("коин", "коина", "коинов"),
    "units": ("единица", "единицы", "единиц"),
    "in_units": ("единицу", "единицы", "единиц"),
}

_variants_uk = {
    "days": ("день", "дня", "днів"),
    "in_days": ("день", "дня", "днів"),
    "months": ("місяць", "місяця", "місяців"),
    "in_months": ("місяць", "місяця", "місяців"),
    "years": ("рік", "роки", "років"),
    "in_years": ("рік", "роки", "років"),
    "weeks": ("тиждень", "тиждня", "тижднів"),
    "in_weeks": ("тиждень", "тиждня", "тижднів"),
    "minutes": ("хвилина", "хвилини", "хвилин"),
    "in_minutes": ("хвилину", "хвилин", "хвилин"),
    "seconds": ("секунда", "секунди", "секунд"),
    "in_seconds": ("секунду", "секунди", "секунд"),
    "hours": ("година", "години", "годин"),
    "in_hours": ("годину", "години", "годин"),
    "coins": ("коїн", "коїна", "коїнів"),
    "units": ("одиниця", "одиниці", "одиниць"),
    "in_units": ("одиницю", "одиниці", "одиниць"),
}


def beautify_number(number: Union[str, int, float]) -> str:
    if isinstance(number, int):
        number = str(number)
    elif isinstance(number, float):
        number, floating = str(number).split(".")
        return f"{beautify_number(number)}.{floating}"

    result = "".join([
        f"{char} " if index % 3 == 0
        else char
        for index, char in enumerate(number[::-1], 1)
    ]
    )[::-1].strip()

    if len(result) > 1 and result[0] in "-+" and result[1] == " ":
        result = result.replace(" ", "", 1)

    return result


def to_int(value: Union[float, str, int]) -> Union[int, str]:
    if isinstance(value, int):
        return value
    elif isinstance(value, float):
        return int(value)
    elif not isinstance(value, str):
        raise ValueError(f"Cannot handle value type {value.__class__}")

    if not len(value):
        return "nan"

    value = value.replace(" ", "")

    integer = "".join(
        [
            char if char not in mod else mod[char]
            for char in value
        ]
    )

    if "." in integer:
        integer = to_float(integer)
        if integer == "nan":
            return "nan"
        integer = int(integer)

    if all(list(map(lambda x: x in mod, value))):
        integer = "1" + integer
    return (
        int(integer)
        if (
                isinstance(integer, int)
                or integer.isdigit()
                or integer.startswith("-") and integer[1:].isdigit()
        )
        else "nan"
    )


def to_float(value: str) -> Union[float, str]:
    if isinstance(value, float):
        return value
    elif isinstance(value, int):
        return float(value)
    elif not isinstance(value, str):
        raise ValueError(f"Cannot handle value type {value.__class__}")

    if value.count(".") < 1:
        value = to_int(value)
        if value == "nan":
            return "nan"
        return float(value)

    if value.count(".") != 1:
        return "nan"

    value = value.replace(" ", "")

    num, floating = value.split(".")

    if len(floating) == 0:
        floating = "0"
    elif len(num) == 0:
        num = "0"

    if floating.endswith("0") and len(floating) > 1:
        floating = floating.rstrip("0")

    if floating.startswith("0") and len(floating) > 1:
        count_of_zeros = 0
        for char in floating:
            if char != "0":
                break
            count_of_zeros += 1

        floating = "0" * count_of_zeros + str(to_int(floating[count_of_zeros:]))
        if "nan" in floating:
            return "nan"

    if num.startswith("0"):
        num = num.strip("0")

    if "nan" == to_int(num):
        return "nan"

    return float(num + "." + floating)


def beautify_represent(number: int, translate: str = "days", number_formatter_func=None):
    if (number := to_int(number)) == 'nan':
        return "unrecognizable value"

    units = abs(number) % 10

    if abs(number) % 100 // 10 == 1:
        result = variants_uk[translate][2]
    elif units == 0 or units > 4:
        result = variants_uk[translate][2]
    elif units > 1:
        result = variants_uk[translate][1]
    else:
        result = variants_uk[translate][0]

    if translate not in (
            "days", "months", "weeks", "years",
            "years", "seconds", "minutes",
            "hours", "in_days", "in_months", "in_weeks", "in_years",
            "in_years", "in_seconds", "in_minutes",
            "in_hours"
    ):
        if number_formatter_func:
            return f"{number_formatter_func(number)} {result}"

        return result

    if number_formatter_func:
        return f"{number_formatter_func(number)} {result}"

    return f"{number} {result}"


def beautify_time(
        time: Union[int, str, timedelta, datetime] = None,
        _in=False,
        days: int = 0,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0
) -> str:
    if time is None and not (days or hours or minutes or seconds):
        raise ValueError(
            "If you don't put the argument time you must put "
            "one or more arguments of days/hours/minutes/seconds"
        )

    if isinstance(time, timedelta):
        time = str(time)
    elif isinstance(time, datetime):
        time = time.strftime("%H:%M:%S")
    elif isinstance(time, int):
        time = str(timedelta(seconds=time))
    elif time is not None and not isinstance(time, str):
        return "unrecognized.."

    if time is not None:
        words = time.split(" ")
        words_count = len(words)
        days = 0
        if words_count == 3 and words[1].startswith("day"):
            days = to_int(words[0])
            if days == "nan":
                days = 0

        # hours, minutes and seconds
        hms = words[-1]
        if "." in hms:
            hms = hms.split(".", maxsplit=1)[0]

        hours, minutes, seconds = map(int, hms.split(":"))

    numerate = ("years", "months", "weeks", "days", "hours", "minutes", "seconds")
    if _in:
        numerate = ("in_years", "in_months", "in_weeks", "in_days", "in_hours", "in_minutes", "in_seconds")

    result = []

    if days // 365:
        result.append(
            beautify_represent(
                days // 365,
                numerate[0]
            )
        )
        days %= 365

    if days // 31:
        result.append(
            beautify_represent(
                days // 31,
                numerate[1]
            )
        )
        days %= 31

    if days // 7:
        result.append(
            beautify_represent(
                days // 7,
                numerate[2]
            )
        )
        days %= 7

    if days:
        result.append(
            beautify_represent(
                days,
                numerate[3]
            )
        )

    if hours:
        result.append(
            beautify_represent(
                hours,
                numerate[4]
            )
        )

    if minutes:
        result.append(
            beautify_represent(
                minutes,
                numerate[5]
            )
        )

    if seconds:
        result.append(
            beautify_represent(
                seconds,
                numerate[6]
            )
        )

    if len(result) == 1:
        return result[0]
    return ", ".join(result[:-1]) + " і " + result[-1]


beautify_date = beautify_time


variables_regex = re.compile(
    r"([\w\d.]+)\s*[:=]\s*(null|nil|infinity|да|нет|true|false|'.*'|\".*\"|[-\dкмkm]+)",
    flags=re.IGNORECASE
)


def parse_variables(string: str) -> dict:
    raw_variables = variables_regex.findall(string)
    variables = {}
    for name, value in raw_variables:
        if to_int(value) != "nan":
            value = to_int(value)
        elif value in ("true", "да"):
            value = True
        elif value in ("false", "нет"):
            value = False
        elif value.startswith("'"):
            value = value.strip("'")
        elif value.startswith('"'):
            value = value.strip('"')
        elif value == "infinity":
            value = float("inf")
        else:
            value = None
        variables[name] = value
    return variables


def from_int(number: Union[int, str]) -> Union[float, str]:
    if isinstance(number, int):
        is_negative = number < 0
        number = str(abs(number))
    elif not isinstance(number, str):
        return "nan"
    else:
        if not number.isdigit():
            return "nan"

        is_negative = int(number) < 0
        number = str(abs(int(number)))

    if len(number) < 1:
        return "0"

    index = 0
    result = number[index]
    while len(number[index + 1:]) % 3 != 0:
        result += number[index + 1]
        index += 1

    slice_index = index + 1
    char = number[slice_index:]
    if len(char) > 0:
        char = int(char)
        if char != 0:
            char = round(char / 10 ** (len(str(char)) - 1))
            result += f",{char}"
    while (
            len(number[slice_index:]) % 3 == 0
            and len(number[slice_index:]) != 0
    ):
        slice_index += 3
        result += "k"
    return ("-" if is_negative else "") + (
        result
    ).replace(
        "kkk", "g"
    ).replace(
        "kk", "m"
    )


def slicer(s, length):
    for index in range(0, len(s), length):
        yield s[index:index + length]


def wordwrap(text: str, limit: int = 20):
    if len(text) <= limit:
        return text
    lines = text.splitlines()

    result = []
    temporary_line = ""

    for line in lines:
        if len(line) < limit:
            result += [line]
            continue

        for word in line.split(" "):
            if word == "":
                word = " "
            if len(word) > limit:
                if len(temporary_line):
                    result.append(temporary_line[:-1])
                    temporary_line = ""
                result.append(
                    "\n".join(
                        slicer(word, limit)
                    )
                )
                continue
            if not word.endswith(" "):
                word += " "
            if len(temporary_line + word) > limit:
                result.append(temporary_line[:-1])
                temporary_line = word
            else:
                temporary_line += word

        if temporary_line != "":
            result.append(temporary_line[:-1])
            temporary_line = ""

    return "\n".join(result)
