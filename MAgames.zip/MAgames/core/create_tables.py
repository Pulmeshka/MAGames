import sqlite3


def create_all():
    connection = sqlite3.connect("core/database/players.db")
    cursor = connection.cursor()
    cursor.execute(
        "CREATE TABLE IF NOT EXISTS "
        "players "
        "("
        "id BIGINT, "
        "balance BIGINT, "
        "rights_level INTEGER, "
        "is_blocked BOOLEAN, "
        "bank BIGINT, "
        "kripto DOUBLE DEFAULT 0.0, "
        "referral BIGINT, "
        "invited BIGINT, "
        "rating DOUBLE, "
        "marry BIGINT ,"
        "awards TEXT, "
        "theft INTEGER, "
        "justice INTEGER, "
        "transfer_limit BIGINT, "
        "uah_balance DOUBLE DEFAULT 0.0"
        ")"
    )
    cursor.execute(
        "CREATE TABLE IF NOT EXISTS "
        "chats_and_participants "
        "("
        "chat_id BIGINT, "
        "user_id BIGINT"
        ")"
    )
    cursor.execute(
        "CREATE TABLE IF NOT EXISTS "
        "chats "
        "("
        "chat_id BIGINT, "
        "balance BIGINT, "
        "protection INTEGER"
        ")"
    )

    cursor.execute(
        "CREATE TABLE IF NOT EXISTS chests"
        "(owner_id BIGINT, type VARCHAR, count BIGINT DEFAULT 1)"
    )

    connection.commit()
