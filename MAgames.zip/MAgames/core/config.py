#list_admin
moderator = []
admin = [1355948406]


chat_admin = 1355948406